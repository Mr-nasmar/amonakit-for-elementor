<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class AmoKit_Elementor_Widget_Modal extends Widget_Base {

    public function get_name() {
        return 'amokit-modal-addons';
    }
    
    public function get_title() {
        return __( 'Modal', 'amokit-addons' );
    }

    public function get_icon() {
        return 'amokit-icon eicon-eye';
    }

    public function get_categories() {
        return [ 'amokit-addons' ];
    }

    public function get_style_depends(){
        return [
            'amokit-widgets',
        ];
    }

    public function get_keywords() {
        return ['modal','lightbox', 'popup', 'modal view', 'popup window', 'amokit', 'Amona Kit', 'addons','widget'];
    }

    public function get_help_url() {
        return 'https://nasdesigns.rf.gd/docs/general-widgets/modal-widget/';
    }
    protected function register_controls() {

        $this->start_controls_section(
            'modal_content',
            [
                'label' => __( 'Modal', 'amokit-addons' ),
            ]
        );
            
            $this->add_control(
                'modal_header_text',
                [
                    'label'   => __( 'Header Content', 'amokit-addons' ),
                    'type'    => Controls_Manager::TEXTAREA,
                    'default' => __('Modal Header Content','amokit-addons'),
                ]
            );

            $this->add_control(
                'content_source',
                [
                    'label'   => esc_html__( 'Select Content Source', 'amokit-addons' ),
                    'type'    => Controls_Manager::SELECT,
                    'default' => 'custom',
                    'options' => [
                        'custom'    => esc_html__( 'Custom', 'amokit-addons' ),
                        "elementor" => esc_html__( 'Elementor Template', 'amokit-addons' ),
                    ],
                ]
            );

             $this->add_control(
                'template_id',
                [
                    'label'       => __( 'Content', 'amokit-addons' ),
                    'type'        => Controls_Manager::SELECT,
                    'default'     => '0',
                    'options'     => amokit_elementor_template(),
                    'condition'   => [
                        'content_source' => "elementor"
                    ],
                ]
            );

             $this->add_control(
                'custom_content',
                [
                    'label' => __( 'Content', 'amokit-addons' ),
                    'type' => Controls_Manager::WYSIWYG,
                    'title' => __( 'Content', 'amokit-addons' ),
                    'show_label' => false,
                    'condition' => [
                        'content_source' =>'custom',
                    ],
                    'default' => __('Lorem ipsum dolor sit amet, consectetur adipis elit, sed do eiusmod tempor incidid ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitati ulla laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in repre in voluptate velit esse cillum dolore eu.','amokit-addons'),
                ]
            );

            $this->add_control(
                'modal_footer_text',
                [
                    'label'   => __( 'Footer Text', 'amokit-addons' ),
                    'type'    => Controls_Manager::TEXTAREA,
                    'default' => __('Modal Footer Content','amokit-addons'),
                ]
            );

        $this->end_controls_section(); // Modal Content Area end

        // Modal Button Section area Start
        $this->start_controls_section(
            'modal_button',
            [
                'label' => __( 'Button', 'amokit-addons' ),
            ]
        );
            
            $this->add_control(
                'button_text',
                [
                    'label'   => __( 'Text', 'amokit-addons' ),
                    'type'    => Controls_Manager::TEXT,
                    'default' => __('Modal Design','amokit-addons'),
                ]
            );

            $this->add_control(
                'button_icon_type',
                [
                    'label' => esc_html__('Icon Type','amokit-addons'),
                    'type' =>Controls_Manager::CHOOSE,
                    'options' =>[
                        'img' =>[
                            'title' =>__('Image','amokit-addons'),
                            'icon' =>'eicon-image-bold',
                        ],
                        'icon' =>[
                            'title' =>__('Icon','amokit-addons'),
                            'icon' =>'eicon-info-circle',
                        ]
                    ],
                ]
            );

            $this->add_control(
                'button_image',
                [
                    'label' => __('Image','amokit-addons'),
                    'type'=>Controls_Manager::MEDIA,
                    'dynamic' => [
                        'active' => true,
                    ],
                    'condition' => [
                        'button_icon_type' => 'img',
                    ]
                ]
            );

            $this->add_group_control(
                Group_Control_Image_Size::get_type(),
                [
                    'name' => 'button_imagesize',
                    'default' => 'large',
                    'separator' => 'none',
                    'condition' => [
                        'button_icon_type' => 'img',
                    ]
                ]
            );

            $this->add_control(
                'button_icon',
                [
                    'label' =>__('Icon','amokit-addons'),
                    'type'=>Controls_Manager::ICONS,
                    'condition' => [
                        'button_icon_type' => 'icon',
                    ]
                ]
            );

            $this->add_responsive_control(
                'modal_icon_position',
                [
                    'label' => __( 'Icon Position', 'amokit-addons' ),
                    'type' => Controls_Manager::CHOOSE,
                    'options' => [
                        'left' => [
                            'title' => __( 'Left', 'amokit-addons' ),
                            'icon' => 'eicon-h-align-left',
                        ],
                        'right' => [
                            'title' => __( 'Right', 'amokit-addons' ),
                            'icon' => 'eicon-h-align-right',
                        ],
                    ],
                    'default' => 'right',
                    'toggle' => false,
                    'condition' =>[
                        'button_icon_type' =>'icon',
                        'button_icon[value]!' =>'',
                    ],
                    'prefix_class' => 'modal_icon_positioning-'
                ]
            );

        $this->end_controls_section(); // Modal Button end

        // Style tab section
        $this->start_controls_section(
            'modal_button_style',
            [
                'label' => __( 'Button', 'amokit-addons' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->start_controls_tabs( 'button_style_tabs' );

                $this->start_controls_tab(
                    'button_style_normal_tab',
                    [
                        'label' => __( 'Normal', 'amokit-addons' ),
                    ]
                );
                    $this->add_control(
                        'button_color',
                        [
                            'label' => __( 'Color', 'amokit-addons' ),
                            'type' => Controls_Manager::COLOR,
                            'default' => '#ffffff',
                            'selectors' => [
                                '{{WRAPPER}} .amo-modal-btn button' => 'color: {{VALUE}};',
                                '{{WRAPPER}} .amo-modal-btn button svg path' => 'fill: {{VALUE}};',
                            ],
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Typography::get_type(),
                        [
                            'name' => 'button_typography',
                            'selector' => '{{WRAPPER}} .amo-modal-btn button',
                            'separator' => 'before',
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Box_Shadow::get_type(),
                        [
                            'name' => 'button_box_shadow',
                            'label' => __( 'Box Shadow', 'amokit-addons' ),
                            'selector' => '{{WRAPPER}} .amo-modal-btn button',
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Background::get_type(),
                        [
                            'name' => 'button_background',
                            'label' => __( 'Background', 'amokit-addons' ),
                            'types' => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .amo-modal-btn button',
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Border::get_type(),
                        [
                            'name' => 'button_border',
                            'label' => __( 'Border', 'amokit-addons' ),
                            'selector' => '{{WRAPPER}} .amo-modal-btn button',
                        ]
                    );

                    $this->add_responsive_control(
                        'button_border_radius',
                        [
                            'label' => esc_html__( 'Border Radius', 'amokit-addons' ),
                            'type' => Controls_Manager::DIMENSIONS,
                            'selectors' => [
                                '{{WRAPPER}} .amo-modal-btn button' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                            ],
                        ]
                    );

                    $this->add_responsive_control(
                        'button_padding',
                        [
                            'label' => __( 'Padding', 'amokit-addons' ),
                            'type' => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors' => [
                                '{{WRAPPER}} .amo-modal-btn button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                            'separator' =>'before',
                        ]
                    );

                    $this->add_control(
                        'button_image_distance',
                        [
                            'label' => esc_html__( 'Image space', 'amokit-addons' ),
                            'type' => Controls_Manager::SLIDER,
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 200,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .amo-modal-btn button img' => 'margin-right: {{SIZE}}{{UNIT}};',
                            ],
                            'condition' =>[
                                'button_icon_type' =>'img',
                            ],
                            'separator' =>'after',
                        ]
                    );

                    $this->add_control(
                        'button_width',
                        [
                            'label' => esc_html__( 'Width', 'amokit-addons' ),
                            'type' => Controls_Manager::SLIDER,
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1200,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .amo-modal-btn button' => 'width: {{SIZE}}{{UNIT}};',
                            ],
                        ]
                    );

                    $this->add_control(
                        'button_height',
                        [
                            'label' => esc_html__( 'Height', 'amokit-addons' ),
                            'type' => Controls_Manager::SLIDER,
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 200,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .amo-modal-btn button' => 'height: {{SIZE}}{{UNIT}};',
                            ],
                        ]
                    );

                    $this->add_responsive_control(
                        'button_align',
                        [
                            'label' => __( 'Alignment', 'amokit-addons' ),
                            'type' => Controls_Manager::CHOOSE,
                            'options' => [
                                'left' => [
                                    'title' => __( 'Left', 'amokit-addons' ),
                                    'icon' => 'eicon-text-align-left',
                                ],
                                'center' => [
                                    'title' => __( 'Center', 'amokit-addons' ),
                                    'icon' => 'eicon-text-align-center',
                                ],
                                'right' => [
                                    'title' => __( 'Right', 'amokit-addons' ),
                                    'icon' => 'eicon-text-align-right',
                                ],
                                'justify' => [
                                    'title' => __( 'Justified', 'amokit-addons' ),
                                    'icon' => 'eicon-text-align-justify',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .amo-modal-btn' => 'text-align: {{VALUE}};',
                            ],
                            'default' => 'left',
                            'separator' =>'after',
                        ]
                    );

                    $this->add_control(
                        'modal_icon_size_opt',
                        [
                            'label' => __( 'Icon Size', 'amokit-addons' ),
                            'type' => Controls_Manager::SLIDER,
                            'size_units' => [ 'px', '%' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                    'step' => 1,
                                ],
                                '%' => [
                                    'min' => 0,
                                    'max' => 100,
                                ],
                            ],
                            'default' => [
                                'unit' => 'px',
                                'size' => '',
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .amo-modal-btn button i' => 'font-size: {{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .amo-modal-btn svg' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
                            ],
                            'condition' =>[
                                'button_icon_type' =>'icon',
                                'button_icon[value]!' =>'',
                            ],
                        ]
                    );

                    $this->add_control(
                        'button_icon_distance',
                        [
                            'label' => esc_html__( 'Icon Space', 'amokit-addons' ),
                            'type' => Controls_Manager::SLIDER,
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 200,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .modal_icon_positioning-left .amo-modal-btn button i, .modal_icon_positioning-left .amo-modal-btn button svg' => 'margin-right: {{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .modal_icon_positioning-right .amo-modal-btn button i, .modal_icon_positioning-right .amo-modal-btn button svg' => 'margin-left: {{SIZE}}{{UNIT}};',
                            ],
                            'condition' =>[
                                'button_icon_type' =>'icon',
                                'button_icon[value]!' =>'',
                            ],
                            'separator' =>'after',
                        ]
                    );

                $this->end_controls_tab(); // Button Normal End

                $this->start_controls_tab(
                    'button_style_hover_tab',
                    [
                        'label' => __( 'Hover', 'amokit-addons' ),
                    ]
                );
                    
                    $this->add_control(
                        'button_hover_color',
                        [
                            'label' => __( 'Color', 'amokit-addons' ),
                            'type' => Controls_Manager::COLOR,
                            'default' => '#ffffff',
                            'selectors' => [
                                '{{WRAPPER}} .amo-modal-btn button:hover' => 'color: {{VALUE}};',
                                '{{WRAPPER}} .amo-modal-btn button:hover svg path' => 'fill: {{VALUE}};',
                            ],
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Background::get_type(),
                        [
                            'name' => 'button_hover_background',
                            'label' => __( 'Background', 'amokit-addons' ),
                            'types' => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .amo-modal-btn button:hover',
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Border::get_type(),
                        [
                            'name' => 'button_hover_border',
                            'label' => __( 'Border', 'amokit-addons' ),
                            'selector' => '{{WRAPPER}} .amo-modal-btn button:hover',
                        ]
                    );

                $this->end_controls_tab(); // Button Hover Tab end

            $this->end_controls_tabs();

        $this->end_controls_section();

        // Style tab section
        $this->start_controls_section(
            'modal_content_box_style',
            [
                'label' => __( 'Modal Box Style', 'amokit-addons' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

            $this->add_responsive_control(
                'modal_content_box_top_spacing',
                [
                    'label' => __( 'Modal Top Space', 'amokit-addons' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'default' => [
                        'unit' => 'px',
                        'size' => '',
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .amo-modal-area .htb-modal-dialog' => 'margin-top: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Background::get_type(),
                [
                    'name' => 'modal_content_box_background',
                    'label' => __( 'Background', 'amokit-addons' ),
                    'types' => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .htb-modal-content',
                ]
            );

            $this->add_responsive_control(
                'modal_content_box_margin',
                [
                    'label' => __( 'Margin', 'amokit-addons' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .htb-modal-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' =>'before',
                ]
            );

            $this->add_responsive_control(
                'modal_content_box_padding',
                [
                    'label' => __( 'Padding', 'amokit-addons' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .htb-modal-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' =>'before',
                ]
            );

            $this->add_group_control(
                Group_Control_Border::get_type(),
                [
                    'name' => 'modal_content_box_border',
                    'label' => __( 'Border', 'amokit-addons' ),
                    'selector' => '{{WRAPPER}} .htb-modal-content',
                ]
            );

            $this->add_responsive_control(
                'modal_content_box_radius',
                [
                    'label' => __( 'Border Radius', 'amokit-addons' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'selectors' => [
                        '{{WRAPPER}} .htb-modal-content' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                    ],
                ]
            );

        $this->end_controls_section();

        // Style Header tab section
        $this->start_controls_section(
            'modal_header_style',
            [
                'label' => __( 'Header', 'amokit-addons' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

            $this->add_control(
                'header_color',
                [
                    'label' => __( 'Color', 'amokit-addons' ),
                    'type' => Controls_Manager::COLOR,
                    'default' => '#444444',
                    'selectors' => [
                        '{{WRAPPER}} .htb-modal-header h5' => 'color: {{VALUE}};',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'header_typography',
                    'selector' => '{{WRAPPER}} .htb-modal-header h5',
                    'separator' => 'before',
                ]
            );

            $this->add_group_control(
                Group_Control_Box_Shadow::get_type(),
                [
                    'name' => 'header_box_shadow',
                    'label' => __( 'Box Shadow', 'amokit-addons' ),
                    'selector' => '{{WRAPPER}} .htb-modal-header',
                ]
            );

            $this->add_group_control(
                Group_Control_Background::get_type(),
                [
                    'name' => 'header_background',
                    'label' => __( 'Background', 'amokit-addons' ),
                    'types' => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .htb-modal-header',
                ]
            );

            $this->add_group_control(
                Group_Control_Border::get_type(),
                [
                    'name' => 'header_border',
                    'label' => __( 'Border', 'amokit-addons' ),
                    'selector' => '{{WRAPPER}} .htb-modal-header',
                ]
            );

            $this->add_responsive_control(
                'header_border_radius',
                [
                    'label' => esc_html__( 'Border Radius', 'amokit-addons' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'selectors' => [
                        '{{WRAPPER}} .htb-modal-header' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                    ],
                ]
            );

            $this->add_responsive_control(
                'header_margin',
                [
                    'label' => __( 'Margin', 'amokit-addons' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .htb-modal-header' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' =>'before',
                ]
            );

            $this->add_responsive_control(
                'header_padding',
                [
                    'label' => __( 'Padding', 'amokit-addons' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .htb-modal-header' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' =>'before',
                ]
            );

            $this->add_control(
                'header_close_btn_note',
                [
                    'type' => Controls_Manager::RAW_HTML,
                    'raw' => sprintf(
                        esc_html__( 'Note: Below, This CSS style to use on your header close button ', 'amokit-addons' )
                    ),
                    'content_classes' => 'elementor-panel-alert',
                    'separator' =>'before',
                ]
            );

            $this->add_control(
                'header_close_btn_color',
                [
                    'label' => __( 'Color', 'amokit-addons' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .htb-modal-header .htb-close' => 'color: {{VALUE}};',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'header_close_btn_typography',
                    'selector' => '{{WRAPPER}} .htb-modal-header .htb-close',
                    'separator' => 'before',
                ]
            );

            $this->add_group_control(
                Group_Control_Background::get_type(),
                [
                    'name' => 'header_close_btn_background',
                    'label' => __( 'Background', 'amokit-addons' ),
                    'types' => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .htb-modal-header .htb-close',
                ]
            );

            $this->add_responsive_control(
                'header_close_btn_padding',
                [
                    'label' => __( 'Padding', 'amokit-addons' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .htb-modal-header .htb-close' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' =>'before',
                ]
            );

            $this->add_group_control(
                Group_Control_Border::get_type(),
                [
                    'name' => 'header_close_btn_border',
                    'label' => __( 'Border', 'amokit-addons' ),
                    'selector' => '{{WRAPPER}} .htb-modal-header .htb-close',
                ]
            );

            $this->add_responsive_control(
                'header_close_btn_radius',
                [
                    'label' => esc_html__( 'Border Radius', 'amokit-addons' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'selectors' => [
                        '{{WRAPPER}} .htb-modal-header .htb-close' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                    ],
                ]
            );

        $this->end_controls_section();

        // Style Footer tab section
        $this->start_controls_section(
            'modal_footer_style',
            [
                'label' => __( 'Footer', 'amokit-addons' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

            $this->add_control(
                'footer_color',
                [
                    'label' => __( 'Color', 'amokit-addons' ),
                    'type' => Controls_Manager::COLOR,
                    'default' => '#444444',
                    'selectors' => [
                        '{{WRAPPER}} .htb-modal-footer p' => 'color: {{VALUE}};',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'footer_typography',
                    'selector' => '{{WRAPPER}} .htb-modal-footer p',
                    'separator' => 'before',
                ]
            );

            $this->add_group_control(
                Group_Control_Background::get_type(),
                [
                    'name' => 'footer_background',
                    'label' => __( 'Background', 'amokit-addons' ),
                    'types' => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .htb-modal-footer',
                ]
            );

            $this->add_group_control(
                Group_Control_Border::get_type(),
                [
                    'name' => 'footer_border',
                    'label' => __( 'Border', 'amokit-addons' ),
                    'selector' => '{{WRAPPER}} .htb-modal-footer',
                ]
            );

            $this->add_responsive_control(
                'footer_border_radius',
                [
                    'label' => esc_html__( 'Border Radius', 'amokit-addons' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'selectors' => [
                        '{{WRAPPER}} .htb-modal-footer' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                    ],
                ]
            );

            $this->add_responsive_control(
                'footer_margin',
                [
                    'label' => __( 'Margin', 'amokit-addons' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .htb-modal-footer' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' =>'before',
                ]
            );

            $this->add_responsive_control(
                'footer_padding',
                [
                    'label' => __( 'Padding', 'amokit-addons' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .htb-modal-footer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' =>'before',
                ]
            );

            $this->add_control(
                'footer_close_txt',
                [
                    'label' => __( 'Footer Close Button', 'amokit-addons' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __( 'Close', 'amokit-addons' ),
                ]
            );

            $this->add_control(
                'footer_close_color',
                [
                    'label' => __( 'Color', 'amokit-addons' ),
                    'type' => Controls_Manager::COLOR,
                    'default' => '#ffffff',
                    'selectors' => [
                        '{{WRAPPER}} .amo-modal-area .htb-btn-secondary' => 'color: {{VALUE}};',
                    ],
                    'condition' =>[
                        'footer_close_txt!'=>'',
                    ]
                ]
            );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'footer_close_typography',
                    'selector' => '{{WRAPPER}} .amo-modal-area .htb-btn-secondary',
                    'separator' => 'before',
                    'condition' =>[
                        'footer_close_txt!'=>'',
                    ]
                ]
            );

            $this->add_group_control(
                Group_Control_Background::get_type(),
                [
                    'name' => 'footer_close_background',
                    'label' => __( 'Background', 'amokit-addons' ),
                    'types' => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .amo-modal-area .htb-btn-secondary',
                    'condition' =>[
                        'footer_close_txt!'=>'',
                    ]
                ]
            );

            $this->add_responsive_control(
                'footer_close_btn_padding',
                [
                    'label' => __( 'Padding', 'amokit-addons' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .amo-modal-area .htb-btn-secondary' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' =>'before',
                ]
            );

            $this->add_group_control(
                Group_Control_Border::get_type(),
                [
                    'name' => 'footer_close_btn_border',
                    'label' => __( 'Border', 'amokit-addons' ),
                    'selector' => '{{WRAPPER}} .amo-modal-area .htb-btn-secondary',
                ]
            );

            $this->add_responsive_control(
                'footer_close_btn_radius',
                [
                    'label' => esc_html__( 'Border Radius', 'amokit-addons' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'selectors' => [
                        '{{WRAPPER}} .amo-modal-area .htb-btn-secondary' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                    ],
                ]
            );

        $this->end_controls_section();

        // Style Footer tab section
        $this->start_controls_section(
            'modal_content_style',
            [
                'label' => __( 'Modal Content', 'amokit-addons' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

            $this->add_control(
                'content_color',
                [
                    'label' => __( 'Color', 'amokit-addons' ),
                    'type' => Controls_Manager::COLOR,
                    'default' => '#444444',
                    'selectors' => [
                        '{{WRAPPER}} .htb-modal-body' => 'color: {{VALUE}};',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'content_typography',
                    'selector' => '{{WRAPPER}} .htb-modal-body',
                    'separator' => 'before',
                ]
            );

            $this->add_group_control(
                Group_Control_Background::get_type(),
                [
                    'name' => 'content_background',
                    'label' => __( 'Background', 'amokit-addons' ),
                    'types' => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .htb-modal-body',
                ]
            );

            $this->add_group_control(
                Group_Control_Border::get_type(),
                [
                    'name' => 'content_border',
                    'label' => __( 'Border', 'amokit-addons' ),
                    'selector' => '{{WRAPPER}} .htb-modal-body',
                ]
            );

            $this->add_responsive_control(
                'content_border_radius',
                [
                    'label' => esc_html__( 'Border Radius', 'amokit-addons' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'selectors' => [
                        '{{WRAPPER}} .htb-modal-body' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                    ],
                ]
            );

            $this->add_responsive_control(
                'content_margin',
                [
                    'label' => __( 'Margin', 'amokit-addons' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .htb-modal-body' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' =>'before',
                ]
            );

            $this->add_responsive_control(
                'content_padding',
                [
                    'label' => __( 'Padding', 'amokit-addons' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .htb-modal-body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' =>'before',
                ]
            );

            $this->add_responsive_control(
                'content_align',
                [
                    'label' => __( 'Alignment', 'amokit-addons' ),
                    'type' => Controls_Manager::CHOOSE,
                    'options' => [
                        'left' => [
                            'title' => __( 'Left', 'amokit-addons' ),
                            'icon' => 'eicon-text-align-left',
                        ],
                        'center' => [
                            'title' => __( 'Center', 'amokit-addons' ),
                            'icon' => 'eicon-text-align-center',
                        ],
                        'right' => [
                            'title' => __( 'Right', 'amokit-addons' ),
                            'icon' => 'eicon-text-align-right',
                        ],
                        'justify' => [
                            'title' => __( 'Justified', 'amokit-addons' ),
                            'icon' => 'eicon-text-align-justify',
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .htb-modal-body' => 'text-align: {{VALUE}};',
                    ],
                    'default' => 'left',
                    'separator' =>'before',
                ]
            );

            $this->add_control(
                'content_width',
                [
                    'label' => esc_html__( 'Modal Width', 'amokit-addons' ),
                    'type' => Controls_Manager::SLIDER,
                    'range' => [
                        'px' => [
                            'min' => 300,
                            'max' => 1200,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .amo-modal-area .htb-modal-dialog' => 'max-width: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );

        $this->end_controls_section();

    }

    protected function render( $instance = [] ) {

        $settings   = $this->get_settings_for_display();

        $id = $this->get_id();
        $this->add_render_attribute( 'amokit_modal_attr', 'class', 'amokit-modal-area htb-modal htb-fade' );
        $this->add_render_attribute( 'amokit_modal_attr', 'id', 'amokitmodal' . esc_attr( $id ) );
       
        ?>
            
            <div class="amo-modal-btn">
                <?php
                    $buttontxt = isset( $settings['button_text'] ) ? wp_kses_post( $settings['button_text'] ) : '';
                    if( $settings['button_icon_type'] == 'img' && !empty( $settings['button_image']['url'] ) ){
                        $buttontxt = Group_Control_Image_Size::get_attachment_image_html( $settings, 'button_imagesize', 'button_image' ).$buttontxt;
                    }elseif( $settings['button_icon_type'] == 'icon' && !empty( $settings['button_icon']['value'] )){
                        $buttontxt = AmoKit_Icon_manager::render_icon( $settings['button_icon'], [ 'aria-hidden' => 'true' ] ).$buttontxt;
                    }

                    echo sprintf('<button type="button" data-toggle="htbmodal" data-target="#amokitmodal%1$s">%2$s</button>', esc_attr( $id ), $buttontxt ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                ?>
            </div>

            <!-- Modal -->
            <div <?php echo $this->get_render_attribute_string( 'amokit_modal_attr' ); ?>>

                <div class="htb-modal-dialog htb-modal-dialog-centered">
                    <div class="htb-modal-content">

                        <div class="htb-modal-header">
                            <?php
                                if( !empty( $settings['modal_header_text'] ) ){
                                    echo '<h5>'.esc_html( $settings['modal_header_text'] ).'</h5>';
                                }
                            ?>
                            <button type="button" class="htb-close" data-dismiss="modal"><span>&times;</span></button>
                        </div>

                        <?php
                            $template_id  = absint( $settings['template_id'] );
                            if ( $settings['content_source'] == 'custom' && !empty( $settings['custom_content'] ) ) {
                                echo '<div class="htb-modal-body">'.wp_kses_post( $settings['custom_content'] ).'</div>';
                            } elseif ( $settings['content_source'] == "elementor" && !empty( $template_id )) {
                                
                                echo '<div class="htb-modal-body">'.Plugin::instance()->frontend->get_builder_content_for_display( $template_id ).'</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                            }
                        ?>

                        <div class="htb-modal-footer">
                            <?php
                                if( !empty( $settings['modal_header_text'] ) ){
                                    echo '<p>'.esc_html( $settings['modal_footer_text'] ).'</p>';
                                }
                                if( !empty( $settings['footer_close_txt'] ) ){
                                    echo '<button type="button" class="htb-btn htb-btn-secondary" data-dismiss="modal">'.esc_html($settings['footer_close_txt'] ).'</button>';
                                }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php
    }
}


<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class AmoKit_Elementor_Widget_Brand extends Widget_Base {

    public function get_name() {
        return 'amokit-brand-addons';
    }
    
    public function get_title() {
        return __( 'Brands', 'amokit-addons' );
    }

    public function get_icon() {
        return 'amokit-icon eicon-image';
    }

    public function get_categories() {
        return [ 'amokit-addons' ];
    }

    public function get_style_depends(){
        return [
            'amokit-widgets',
        ];
    }
    public function get_keywords() {
        return ['brands', 'brand', 'logo', 'logos', 'amokit', 'Amona Kit', 'addons'];
    }

    public function get_help_url() {
        return 'https://nasdesigns.rf.gd/docs/general-widgets/brand-widget/';
    }
    protected function register_controls() {

        $this->start_controls_section(
            'brand_content',
            [
                'label' => __( 'Brands', 'amokit-addons' ),
            ]
        );

            $this->add_control(
                'amokit_brand_style',
                [
                    'label' => __( 'Style', 'amokit-addons' ),
                    'type' => 'amokit-preset-select',
                    'default' => '1',
                    'options' => [
                        '1'   => __( 'Style One', 'amokit-addons' ),
                        '2'   => __( 'Style Two', 'amokit-addons' ),
                        '3'   => __( 'Style Three', 'amokit-addons' ),
                        '4'   => __( 'Style Four', 'amokit-addons' ),
                        '5'   => __( 'Style Five', 'amokit-addons' ),
                        '6'   => __( 'Style Six', 'amokit-addons' ),
                        '7'   => __( 'Style Seven', 'amokit-addons' ),
                    ],
                ]
            );

            $repeater = new Repeater();

            $repeater->add_control(
                'amokit_brand_title',
                [
                    'label'   => __( 'Title', 'amokit-addons' ),
                    'type'    => Controls_Manager::TEXT,
                    'default' => 'Brand Logo',
                ]
            );

            $repeater->add_control(
                'amokit_brand_logo',
                [
                    'label' => __( 'Partner Logo', 'amokit-addons' ),
                    'type' => Controls_Manager::MEDIA,
                    'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
                ]
            );

            $repeater->add_group_control(
                Group_Control_Image_Size::get_type(),
                [
                    'name' => 'amokit_brand_logo_size',
                    'default' => 'large',
                    'separator' => 'none',
                ]
            );

            $repeater->add_control(
                'amokit_brand_link',
                [
                    'label'   => __( 'Partner Link', 'amokit-addons' ),
                    'type'    => Controls_Manager::TEXT,
                    'default' => __( '#', 'amokit-addons' ),
                ]
            );

            $this->add_control(
                'amokit_brand_list',
                [
                    'type'    => Controls_Manager::REPEATER,
                    'fields'  => $repeater->get_controls(),
                    'default' => [

                        [
                            'amokit_brand_title'      => 'Brand Logo',
                            'amokit_brand_link'       => __( '#', 'amokit-addons' ),
                        ],
                    ],
                    'title_field' => '{{{ amokit_brand_title }}}',
                ]
            );


        $this->end_controls_section();

        // Style tab section
        $this->start_controls_section(
            'amokit_brand_style_section',
            [
                'label' => __( 'Style', 'amokit-addons' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
            
            $this->add_responsive_control(
                'amokit_brand_section_margin',
                [
                    'label' => __( 'Margin', 'amokit-addons' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .amo-brands-area' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' =>'before',
                ]
            );

            $this->add_responsive_control(
                'amokit_brand_section_padding',
                [
                    'label' => __( 'Padding', 'amokit-addons' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .amo-brands-area' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' =>'before',
                ]
            ); 

        $this->end_controls_section(); // Brand section style end

        // Style tab brand logo section
        $this->start_controls_section(
            'amokit_brand_logo_style',
            [
                'label' => __( 'Brand Logo', 'amokit-addons' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );



        $this->start_controls_tabs('brand_style_tabs');

            // Brand Normal tab Start
            $this->start_controls_tab(
                'brand_style_normal_tab',
                [
                    'label' => __( 'Normal', 'amokit-addons' ),
                ]
            );

                $this->add_group_control(
                    Group_Control_Background::get_type(),
                    [
                        'name' => 'amokit_brand_logo_background',
                        'label' => __( 'Background', 'amokit-addons' ),
                        'types' => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .single-partner',
                        'condition' =>[
                            'amokit_brand_style' => array( '1','5','7' ),
                        ]
                    ]
                );

                $this->add_group_control(
                    Group_Control_Box_Shadow::get_type(),
                    [
                        'name' => 'amokit_brand_logo_box_shadow',
                        'label' => __( 'Box Shadow', 'amokit-addons' ),
                        'selector' => '{{WRAPPER}} .single-partner',
                        'condition' =>[
                            'amokit_brand_style' => array( '1','5','7' ),
                        ]
                    ]
                );

                $this->add_group_control(
                    Group_Control_Background::get_type(),
                    [
                        'name' => 'amokit_brand_logo_background_2',
                        'label' => __( 'Background', 'amokit-addons' ),
                        'types' => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} ul.brand-list li',
                        'condition' =>[
                            'amokit_brand_style' => array( '2','3','4','6' ),
                        ]
                    ]
                );

                $this->add_group_control(
                    Group_Control_Box_Shadow::get_type(),
                    [
                        'name' => 'amokit_brand_logo_box_shadow_2',
                        'label' => __( 'Box Shadow', 'amokit-addons' ),
                        'selector' => '{{WRAPPER}} ul.brand-list li',
                        'condition' =>[
                            'amokit_brand_style' => array( '2','3','4','6' ),
                        ]
                    ]
                );


            $this->end_controls_tab(); // Brand Normal tab end

            // Brand Hover tab start
            $this->start_controls_tab(
                'brand_style_hover_tab',
                [
                    'label' => __( 'Hover', 'amokit-addons' ),
                ]
            );

                $this->add_group_control(
                    Group_Control_Background::get_type(),
                    [
                        'name' => 'amokit_brand_logo_background_hover',
                        'label' => __( 'Background', 'amokit-addons' ),
                        'types' => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .single-partner:hover',
                        'condition' =>[
                            'amokit_brand_style' => array( '1','5','7' ),
                        ]
                    ]
                );

                $this->add_group_control(
                    Group_Control_Box_Shadow::get_type(),
                    [
                        'name' => 'amokit_brand_logo_box_shadow_hover',
                        'label' => __( 'Box Shadow', 'amokit-addons' ),
                        'selector' => '{{WRAPPER}} .single-partner:hover',
                        'condition' =>[
                            'amokit_brand_style' => array( '1','5','7' ),
                        ]
                    ]
                );

                $this->add_group_control(
                    Group_Control_Background::get_type(),
                    [
                        'name' => 'amokit_brand_logo_background_2_hover',
                        'label' => __( 'Background', 'amokit-addons' ),
                        'types' => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} ul.brand-list li:hover',
                        'condition' =>[
                            'amokit_brand_style' => array( '2','3','4','6' ),
                        ]
                    ]
                );

                $this->add_group_control(
                    Group_Control_Box_Shadow::get_type(),
                    [
                        'name' => 'amokit_brand_logo_box_shadow_2_hover',
                        'label' => __( 'Box Shadow', 'amokit-addons' ),
                        'selector' => '{{WRAPPER}} ul.brand-list li:hover',
                        'condition' =>[
                            'amokit_brand_style' => array( '2','3','4','6' ),
                        ]
                    ]
                );

                $this->add_control(
                    'amokit_brand_logo_duration',
                    [
                        'label' => __( 'Transition Duration', 'amokit-addons' ),
                        'type'  => Controls_Manager::SLIDER,
                        'range' => [
                            'px' => [
                                'min' => 0.1,
                                'max' => 3,
                                'step' => 0.1,
                            ],
                        ],
                        'default' => [
                            'size' => 0.3,
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .single-partner' => 'transition: all {{SIZE}}s cubic-bezier(0.645, 0.045, 0.355, 1);',
                            '{{WRAPPER}} ul.brand-list li' => 'transition: all {{SIZE}}s cubic-bezier(0.645, 0.045, 0.355, 1);',
                        ],
                    ]
                );

            $this->end_controls_tab(); // Brand Hover tab end

        $this->end_controls_tabs();

            $this->add_responsive_control(
                'amokit_brand_logo_margin',
                [
                    'label' => __( 'Margin', 'amokit-addons' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-partner' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} ul.brand-list li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' =>'before',
                ]
            );

            $this->add_responsive_control(
                'amokit_brand_logo_padding',
                [
                    'label' => __( 'Padding', 'amokit-addons' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-partner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} ul.brand-list li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' =>'before',
                ]
            );

            $this->add_group_control(
                Group_Control_Border::get_type(),
                [
                    'name' => 'amokit_brand_logo_border',
                    'label' => __( 'Border', 'amokit-addons' ),
                    'selector' => '{{WRAPPER}} .single-partner',
                    'condition' =>[
                        'amokit_brand_style' => array( '1','5','7' ),
                    ]
                ]
            );

            $this->add_group_control(
                Group_Control_Border::get_type(),
                [
                    'name' => 'amokit_brand_logo_border_2',
                    'label' => __( 'Border', 'amokit-addons' ),
                    'selector' => '{{WRAPPER}} ul.brand-list li',
                    'condition' =>[
                        'amokit_brand_style' => array( '2','3','4','6' ),
                    ]
                ]
            );

            $this->add_responsive_control(
                'amokit_brand_logo_borderradius',
                [
                    'label' => esc_html__( 'Border Radius', 'amokit-addons' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'selectors' => [
                        '{{WRAPPER}} .single-partner' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                        '{{WRAPPER}} ul.brand-list li' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                    ],
                ]
            );

        $this->end_controls_section(); // Brand Logo style end

    }

    protected function render( $instance = [] ) {

        $settings   = $this->get_settings_for_display();

        $this->add_render_attribute( 'brands_area_attr', 'class', 'amokit-brands-area' );
        $this->add_render_attribute( 'brands_area_attr', 'class', 'amokit-brands-style-' . esc_attr( $settings['amokit_brand_style'] ) );

        ?>
            <div <?php echo $this->get_render_attribute_string( 'brands_area_attr' ); ?> >

                <?php if( $settings['amokit_brand_style'] == 2 || $settings['amokit_brand_style'] == 3 || $settings['amokit_brand_style'] == 4 || $settings['amokit_brand_style'] == 6 ): ?>
                    <ul class="brand-list">
                        <?php foreach ( $settings['amokit_brand_list'] as $brandimage ): ?>
                            <li>
                                <?php
                                    if( !empty($brandimage['amokit_brand_link']) ){
                                        printf('<a href="%1$s">%2$s</a>', esc_url( $brandimage['amokit_brand_link'] ),Group_Control_Image_Size::get_attachment_image_html( $brandimage, 'amokit_brand_logo_size', 'amokit_brand_logo' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                                    }else{
                                        echo Group_Control_Image_Size::get_attachment_image_html( $brandimage, 'amokit_brand_logo_size', 'amokit_brand_logo' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                                    }
                                ?>
                            </li>
                        <?php endforeach;?>
                    </ul>

                <?php elseif( $settings['amokit_brand_style'] == 5 || $settings['amokit_brand_style'] == 7):?>
                    <div class="brand-list-area">
                        <?php foreach ( $settings['amokit_brand_list'] as $brandimage ): ?>
                            <div class="brand-logo-col">
                                <div class="single-partner">
                                    <?php
                                        if( !empty($brandimage['amokit_brand_link']) ){
                                            printf('<a href="%1$s">%2$s</a>', esc_url( $brandimage['amokit_brand_link'] ),Group_Control_Image_Size::get_attachment_image_html( $brandimage, 'amokit_brand_logo_size', 'amokit_brand_logo' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                                        }else{
                                            echo Group_Control_Image_Size::get_attachment_image_html( $brandimage, 'amokit_brand_logo_size', 'amokit_brand_logo' );  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                                        }
                                    ?>
                                </div>
                            </div>
                        <?php endforeach;?>
                    </div>

                <?php else:?>
                    <?php foreach ( $settings['amokit_brand_list'] as $brandimage ): ?>
                        <div class="single-partner">
                            <?php
                                if( !empty($brandimage['amokit_brand_link']) ){
                                    printf('<a href="%1$s">%2$s</a>', esc_url( $brandimage['amokit_brand_link'] ) ,Group_Control_Image_Size::get_attachment_image_html( $brandimage, 'amokit_brand_logo_size', 'amokit_brand_logo' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                                }else{
                                    echo Group_Control_Image_Size::get_attachment_image_html( $brandimage, 'amokit_brand_logo_size', 'amokit_brand_logo' );  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                                }
                            ?>
                        </div>
                    <?php endforeach;?>
                <?php endif;?>
            </div>
        <?php
    }
}


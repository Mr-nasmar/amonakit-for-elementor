<?php
require_once( AMONAKIT_ADDONS_PL_PATH.'extensions/amo-builder/classes/class.header_footer.php' );
require_once( AMONAKIT_ADDONS_PL_PATH.'extensions/amo-builder/classes/class.template_builder.php' );
require_once( AMONAKIT_ADDONS_PL_PATH.'extensions/amo-builder/classes/class.widgets_control.php' );
<div class="wrap amokit-settings-page-wrapper">
    <div id="amokit-opt-admin-app"></div>
    <?php include_once AMOKITOPT_INCLUDES .'/templates/sidebar-banner.php'; ?>
</div>
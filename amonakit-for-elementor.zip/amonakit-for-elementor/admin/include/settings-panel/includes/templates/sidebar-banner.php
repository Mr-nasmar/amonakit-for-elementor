<?php 
ob_start(); 
?>
<div class="amooptions-sidebar-adds-area">
<?php 

$template_data = AmoKit_Template_Library::instance()->get_templates_info();
    if( is_plugin_active('amokit-pro/amokit_pro.php') ){
        $amokit_license_title = apply_filters('amokit_license_title', 'lifetime' ); 
        if ( !str_contains( $amokit_license_title, 'Growth' ) && !str_contains( $amokit_license_title, 'Unlimited - Lifetime' ) ) {

            if( isset( $template_data['notices']['sidebar'][1]['status'] ) && !empty( $template_data['notices']['sidebar'][1]['status'] ) ){
                ?>
                <a href="<?php echo esc_url( $template_data['notices']['sidebar'][1]['bannerlink'] ); ?>" target="_blank">
                    <img class="amooptions-banner-img" src="<?php echo esc_url( $template_data['notices']['sidebar'][1]['bannerimage'] ); ?>" alt="<?php echo esc_attr__( 'Amona Kit Addons', 'amokit-addons' ); ?>"/>
                </a>
                <?php
            }
        }
    }else{

        if( isset( $template_data['notices']['sidebar'][0]['status'] ) && !empty( $template_data['notices']['sidebar'][0]['status'] )){
            ?>
            <a href="<?php echo esc_url( $template_data['notices']['sidebar'][0]['bannerlink'] ); ?>" target="_blank">
                <img  class="amooptions-banner-img" src="<?php echo esc_url( $template_data['notices']['sidebar'][0]['bannerimage'] ); ?>" alt="<?php echo esc_attr__( 'Amona Kit Addons', 'amokit-addons' ); ?>"/>
            </a>
         <?php 
        }
    }
    ?>
    <div class="amooption-rating-area">
        <div class="amooption-rating-icon">
            <img src="<?php echo esc_url(AMONAKIT_ADDONS_PL_URL.'admin/assets/images/icon/rating.png'); ?>" alt="<?php echo esc_attr__( 'Rating icon', 'amokit-addons' ); ?>">
        </div>
        <div class="amooption-rating-intro">
            <?php echo esc_html__('If you’re loving how our product has helped your business, please let the WordPress community know by','amokit-addons'); ?> <a target="_blank" href="https://wordpress.org/support/plugin/amo-kit-for-elementor/reviews/?filter=5#new-post"><?php echo esc_html__( 'leaving us a review on our WP repository', 'amokit-addons' ); ?></a>. <?php echo esc_html__( 'Which will motivate us a lot.', 'amokit-addons' ); ?>
        </div>
    </div>

</div>
<?php echo apply_filters('amokit_sidebar_adds_banner', ob_get_clean() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
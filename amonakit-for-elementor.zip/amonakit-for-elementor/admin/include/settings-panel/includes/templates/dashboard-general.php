<?php
$subcribeFormAtts = '';
$subcribeFormAtts .= ' data-amokit-button-text="' . esc_attr__( 'Subscribe', 'amokit-addons' ) . '"';
$subcribeFormAtts .= ' data-amokit-processing-text="'. esc_attr__( 'Subscribing...', 'amokit-addons' ) . '"';
$subcribeFormAtts .= ' data-amokit-completed-text="' . esc_attr__( 'Subscribed', 'amokit-addons' ) . '"';
$subcribeFormAtts .= ' data-amokit-ajax-error-text="' . esc_attr__( 'Something went wrong.', 'amokit-addons' ) . '"';

ob_start();
?>
<div class="amo-general-tabs">
<div class="amo-admin-main-tab-pane-inner">
        <!-- Banner Start -->
        <div class="amo-admin-banner">
            <img src="<?php echo esc_url( AMOKITOPT_URL . '/assets/images/dashboard-welcome.png' ); ?>" alt="<?php echo esc_attr__('Welcome To Amona Kit','amokit-addons');?>">
        </div>
        <!-- Banner End -->

        <!-- Infoboxes Start -->
        <div class="amo-admin-infoboxes">

            <!-- Infobox Start -->
            <div class="amo-admin-infobox">
                <div class="amo-admin-infobox-icon"><img src="<?php echo esc_url( AMOKITOPT_URL . '/assets/images/info-icon/documentation.png' ); ?>" alt="<?php echo esc_attr__('documentation','amokit-addons');?>"></div>
                <div class="amo-admin-infobox-content">
                    <h3 class="amo-admin-infobox-title"><?php echo esc_html__('Documentation','amokit-addons'); ?></h3>
                    <p class="amo-admin-infobox-text"><?php echo esc_html__('We\'ve organized the documentation and kept it up to date on a regular basis. This manual will assist you in using our plugin effectively.','amokit-addons');?></p>
                    <a href="https://nasdesigns.rf.gd/docs/" class="amo-admin-btn amokit-admin-btn-primary-outline" target="_blank"><span><?php echo esc_html__('Get Now','amokit-addons'); ?></span></a>
                </div>
            </div>
            <!-- Infobox End -->

            <!-- Infobox Start -->
            <div class="amo-admin-infobox">
                <div class="amo-admin-infobox-icon"><img src="<?php echo esc_url( AMOKITOPT_URL . '/assets/images/info-icon/video-tutorial.png' ); ?>" alt="<?php echo esc_attr__('video tutorial','amokit-addons');?>"></div>
                <div class="amo-admin-infobox-content">
                    <h3 class="amo-admin-infobox-title"><?php echo esc_html__('Video Tutorial','amokit-addons'); ?></h3>
                    <p class="amo-admin-infobox-text"><?php echo esc_html__('We create videos to make our customers comprehend the product quickly. Using video tutorials is a fantastic method to learn how to use our plugins. We\'ve compiled a list of videos for you.','amokit-addons'); ?></p>
                    <a href="https://www.youtube.com/watch?v=d7jAiAYusUg&list=PLk25BQFrj7wEEGUHn9x2zwOql990bZAo_&index=1" class="amo-admin-btn amokit-admin-btn-primary-outline" target="_blank"><span><?php echo esc_html__('Video Tutorial','amokit-addons'); ?></span></a>
                </div>
            </div>
            <!-- Infobox End -->

            <!-- Infobox Start -->
            <div class="amo-admin-infobox">
                <div class="amo-admin-infobox-icon"><img src="<?php echo esc_url( AMOKITOPT_URL . '/assets/images/info-icon/support.png' ); ?>" alt="<?php echo esc_attr__('Support','amokit-addons');?>"></div>
                <div class="amo-admin-infobox-content">
                    <h3 class="amo-admin-infobox-title"><?php echo esc_html__('Support','amokit-addons'); ?></h3>
                    <p class="amo-admin-infobox-text"><?php echo esc_html__('Please do not hesitate to contact us if you require assistance or want a free store set-up. We will assist you within 12-24 hours of receiving your inquiry.','amokit-addons');?></p>
                    <a href="https://nasdesigns.rf.gd/contact/" class="amo-admin-btn amokit-admin-btn-primary-outline" target="_blank"><span><?php echo esc_html__('Get Support','amokit-addons'); ?></span></a>
                </div>
            </div>
            <!-- Infobox End -->

            <!-- Infobox Start -->
            <div class="amo-admin-infobox">
                <div class="amo-admin-infobox-icon"><img src="<?php echo esc_url( AMOKITOPT_URL . '/assets/images/info-icon/missing-feature.png' ); ?>" alt="<?php echo esc_attr__('missing feature','amokit-addons');?>"></div>
                <div class="amo-admin-infobox-content">
                    <h3 class="amo-admin-infobox-title"><?php echo esc_html__('Missing any Feature?','amokit-addons'); ?></h3>
                    <p class="amo-admin-infobox-text"><?php echo esc_html__('Have you ever noticed any missing features? Please notify us if you do. As soon as possible, our staff will add any necessary features based on your requests. Our commitment to our clients is second to none. We always attempt to fulfill their demands.','amokit-addons'); ?></p>
                    <a href="https://nasdesigns.rf.gd/contact/" class="amo-admin-btn amokit-admin-btn-primary-outline" target="_blank"><span><?php echo esc_html__('Request','amokit-addons'); ?></span></a>
                </div>
            </div>
            <!-- Infobox End -->
            <!-- Infobox Start -->
            <div class="amo-admin-infobox">
                <div class="amo-admin-infobox-icon"><img src="<?php echo esc_url( AMOKITOPT_URL . '/assets/images/info-icon/happy-with-us.png' ); ?>" alt="<?php echo esc_attr__('happy with us','amokit-addons');?>"></div>
                <div class="amo-admin-infobox-content">
                    <h3 class="amo-admin-infobox-title"><?php echo esc_html__('Happy With us?','amokit-addons'); ?></h3>
                    <p class="amo-admin-infobox-text"><?php echo esc_html__('If you’re loving how our product has helped your business, please let the WordPress community know by leaving us a review on our WP repository. Which will motivate us a lot.','amokit-addons'); ?></p>
                    <a href="https://wordpress.org/support/plugin/amo-kit-for-elementor/reviews/?filter=5#new-post" class="amo-admin-btn amokit-admin-btn-primary-outline" target="_blank"><span><?php echo esc_html__('Sent Feedback','amokit-addons'); ?></span></a>
                </div>
            </div>
            <!-- Infobox End -->
            <!-- Infobox Start -->
            <div class="amo-admin-infobox">
                <div class="amo-admin-infobox-icon"><img src="<?php echo esc_url( AMOKITOPT_URL . '/assets/images/info-icon/woolentor.png' ); ?>" alt="<?php echo esc_attr__('woolentor','amokit-addons');?>"></div>
                <div class="amo-admin-infobox-content">
                    <h3 class="amo-admin-infobox-title"><?php echo esc_html__('ShopLentor','amokit-addons'); ?></h3>
                    <p class="amo-admin-infobox-text"><?php echo esc_html__('Take your WooCommerce store to another level using ShopLentor. Creating an exquisite yet professional online store is just a matter of a few clicks with this plugin.','amokit-addons'); ?></p>
                    <a href="https://woolentor.com/" class="amo-admin-btn amokit-admin-btn-primary-outline" target="_blank"><span><?php echo esc_html__('Learn More','amokit-addons'); ?></span></a>
                </div>
            </div>
            <!-- Infobox End -->

        </div>
        <!-- Infoboxes End -->

        <!-- Subscribe Banner Start -->
        <div class="amo-admin-subscribe">
            <div class="amo-admin-subscribe-content">
                <h3 class="amo-admin-subscribe-title"><?php echo esc_html__('Subscribe and Get Offers','amokit-addons'); ?></h3>
                <p class="amo-admin-subscribe-text"><?php echo esc_html__('Sign up for our email list to get discounts, exclusive offers, the latest items, and news in your inbox.','amokit-addons');?></p>
            </div>
            <div class="amo-admin-subscribe-wrapper">
                <form action="#" class="amo-admin-subscribe-form" <?php echo wp_kses_post( trim( $subcribeFormAtts ) ); ?>>
                    <input type="email" value="<?php echo esc_attr( get_bloginfo('admin_email') ); ?>">
                    <button type="submit"><?php esc_html_e( 'Subscribe', 'amokit-addons' ) ?></button>
                </form>
                <span class="amo-subscribe-status"></span>
            </div>
            <!-- <a href="https://hasthemes.com/subscribe-and-get-offers/" class="amo-admin-btn amokit-admin-btn-primary" target="_blank"><?php echo esc_html__('Subscribe','amokit-addons'); ?></a> -->
        </div>
        <!-- Subscribe Banner End -->
    </div>
</div>
<?php echo apply_filters('amokit_dashboard_general', ob_get_clean() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
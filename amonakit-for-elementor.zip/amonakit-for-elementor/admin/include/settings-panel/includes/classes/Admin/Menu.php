<?php
namespace AmoKitOpt\Admin;

class Menu {

    /**
     * [init]
     */
    public function init() {
        add_action( 'admin_menu', [ $this, 'admin_menu' ], 220 );
    }

    /**
     * Register Menu
     *
     * @return void
     */
    public function admin_menu(){
        global $submenu;

        $slug        = 'amokit-addons';
        $capability  = 'manage_options';

        $hook = add_menu_page(
            esc_html__( 'amokit Addons', 'amokit-addons' ),
            esc_html__( 'amokit Addons', 'amokit-addons' ),
            $capability,
            $slug,
            [ $this, 'plugin_page' ],
            AMONAKIT_ADDONS_PL_URL.'admin/assets/images/menu-icon.svg',
            59
        );

        if ( current_user_can( $capability ) ) {
            $submenu[ $slug ][] = array( esc_html__( 'Settings', 'amokit-addons' ), $capability, 'admin.php?page=' . $slug . '#/general' );
        }

        add_action( 'load-' . $hook, [ $this, 'init_hooks'] );

    }

    /**
     * Initialize our hooks for the admin page
     *
     * @return void
     */
    public function init_hooks() {
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
    }

    /**
     * Load scripts and styles for the app
     *
     * @return void
     */
    public function enqueue_scripts() {
        wp_enqueue_style('amokitopt-sweetalert2');
        wp_enqueue_style( 'amokitopt-admin' );
        wp_enqueue_style( 'amokitopt-style' );
        wp_enqueue_script( 'amokitopt-admin' );

        $option_localize_script = [
            'adminUrl'      => admin_url( '/' ),
            'ajaxUrl'       => admin_url( 'admin-ajax.php' ),
            'rootApiUrl'    => esc_url_raw( rest_url() ),
            'restNonce'     => wp_create_nonce( 'wp_rest' ),
            'verifynonce'   => wp_create_nonce( 'amokitopt_verifynonce' ),
            'tabs'          => Options_Field::instance()->get_settings_tabs(),
            'sections'      => Options_Field::instance()->get_settings_subtabs(),
            'settings'      => Options_Field::instance()->get_registered_settings(),
            'options'       => amokitopt_get_options( Options_Field::instance()->get_registered_settings() ),
            'labels'        => [
                'pro' => __( 'Pro', 'amokit-addons' ),
                'modal' => [
                    'title' => __( 'BUY PRO', 'amokit-addons' ),
                    'buynow' => __( 'Buy Now', 'amokit-addons' ),
                    'desc' => __( 'Our free version is great, but it doesn\'t have all our advanced features. The best way to unlock all of the features in our plugin is by purchasing the pro version.', 'amokit-addons' )
                ],
                'saveButton' => [
                    'text'   => __( 'Save Settings', 'amokit-addons' ),
                    'saving' => __( 'Saving...', 'amokit-addons' ),
                    'saved'  => __( 'Data Saved', 'amokit-addons' ),
                ],
                'enableAllButton' => [
                    'enable'   => __( 'Enable All', 'amokit-addons' ),
                    'disable'  => __( 'Disable All', 'amokit-addons' ),
                ],
                'resetButton' => [
                    'text'   => __( 'Reset All Settings', 'amokit-addons' ),
                    'reseting'  => __( 'Resetting...', 'amokit-addons' ),
                    'reseted'  => __( 'All Data Restored', 'amokit-addons' ),
                    'alert' => [
                        'one'=>[
                            'title' => __( 'Are you sure?', 'amokit-addons' ),
                            'text' => __( 'It will reset all the settings to default, and all the changes you made will be deleted.', 'amokit-addons' ),
                            'confirm' => __( 'Yes', 'amokit-addons' ),
                            'cancel' => __( 'No', 'amokit-addons' ),
                        ],
                        'two'=>[
                            'title' => __( 'Reset!', 'amokit-addons' ),
                            'text' => __( 'All settings has been reset successfully.', 'amokit-addons' ),
                            'confirm' => __( 'OK', 'amokit-addons' ),
                        ]
                    ],
                ]
            ]
        ];

        // update existing data to new Menu builder module settings default option
        $updated_megamenu_options = [
            "megamenubuilder" =>  wp_json_encode([
                "megamenubuilder_enable"   => amokit_get_option('megamenubuilder', 'amokit_advance_element_tabs'),
                "menu_items_color"           => amokit_get_option('menu_items_color', 'amokitmenu_setting_tabs'),
                "menu_items_hover_color"     => amokit_get_option('menu_items_hover_color', 'amokitmenu_setting_tabs'),
                "sub_menu_width"             => amokit_get_option('sub_menu_width', 'amokitmenu_setting_tabs'),
                "sub_menu_bg_color"          => amokit_get_option('sub_menu_bg_color', 'amokitmenu_setting_tabs'),
                "sub_menu_items_color"       => amokit_get_option('sub_menu_items_color', 'amokitmenu_setting_tabs'),
                "sub_menu_items_hover_color" => amokit_get_option('sub_menu_items_hover_color', 'amokitmenu_setting_tabs'),
                "mega_menu_width"            => amokit_get_option('mega_menu_width', 'amokitmenu_setting_tabs'),
                "mega_menu_bg_color"         => amokit_get_option('mega_menu_bg_color', 'amokitmenu_setting_tabs'),
            ]),
        ];
        // megamenu modules defautl option's value update
        if ( empty( amokit_get_module_option( 'amokit_megamenu_module_settings' ) ) ) {
            update_option( 'amokit_megamenu_module_settings' , $updated_megamenu_options );
            update_option( 'amokitmenu_setting_tabs' , '' );
        }

        // update existing data to new theme builder module settings default option
        $updated_theme_builder_options = [
            "themebuilder" =>  wp_json_encode([
                "themebuilder_enable"   => amokit_get_option('themebuilder', 'amokit_advance_element_tabs'),
                "single_blog_page"           => amokit_get_option('single_blog_page', 'amokitbuilder_templatebuilder_tabs'),
                "archive_blog_page"     => amokit_get_option('archive_blog_page', 'amokitbuilder_templatebuilder_tabs'),
                "header_page"             => amokit_get_option('header_page', 'amokitbuilder_templatebuilder_tabs'),
                "footer_page"          => amokit_get_option('footer_page', 'amokitbuilder_templatebuilder_tabs'),
                "search_page"       => amokit_get_option('search_page', 'amokitbuilder_templatebuilder_tabs'),
                "error_page" => amokit_get_option('error_page', 'amokitbuilder_templatebuilder_tabs'),
                "coming_soon_page"            => amokit_get_option('coming_soon_page', 'amokitbuilder_templatebuilder_tabs'),
            ]),
        ];
        // megamenu modules defautl option's value update
        if ( empty( amokit_get_module_option( 'amokit_themebuilder_module_settings' ) ) ) {
            update_option( 'amokit_themebuilder_module_settings' , $updated_theme_builder_options );
            update_option( 'amokitbuilder_templatebuilder_tabs' , '' );
        }
        wp_localize_script( 'amokitopt-admin', 'amokitOptions', $option_localize_script );
    }

    /**
     * Render our admin page
     *
     * @return void
     */
    public function plugin_page() {
        ob_start();
		include_once AMOKITOPT_INCLUDES .'/templates/settings-page.php';
		echo ob_get_clean(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }

}

<?php
namespace AmoKitOpt\Admin;

class Options_Field {

    /**
     * [$_instance]
     * @var null
     */
    private static $_instance = null;

    /**
     * [instance] Initializes a singleton instance
     * @return [Admin]
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function get_settings_tabs(){
        $tabs = array(
            'general' => [
                'id'    => 'amokit_pro_vs_free_tabs',
                'title' => esc_html__( 'General', 'amokit-addons' ),
                'icon'  => 'amokit amokit-settings',
                'content' => [
                    'header' => false,
                    'footer' => false,
                    'title' => __( 'Free VS Pro', 'amokit-addons' ),
                    'desc'  => __( 'Freely use these elements to create your site. You can enable which you are not using, and, all associated assets will be disable to improve your site loading speed.', 'amokit-addons' ),
                ],
            ],
            'elements' => [
                'id'    => 'amokit_element_tabs',
                'title' => esc_html__( 'Elements', 'amokit-addons' ),
                'icon'  => 'amokit amokit-element',
                'content' => [
                    'column' => 3,
                    'title' => __( 'Widget List', 'amokit-addons' ),
                    'desc'  => __( 'Freely use these elements to create your site. You can enable which you are not using, and, all associated assets will be disable to improve your site loading speed.', 'amokit-addons' ),
                ],
            ],
            'gutenberg' => [
                'id'    => 'amokit_gutenberg_tabs',
                'title' => esc_html__( 'Gutenberg', 'amokit-addons' ),
                'icon'  => 'amokit amokit-element',
                'content' => [
                    'column' => 3,
                    'title' => __( 'Gutenberg Blocks List', 'amokit-addons' ),
                    'desc'  => __( 'Freely use these Gutenberg Blocks to create your site. You can disable which you are not using, and, all associated assets will be disable to improve your site loading speed.', 'amokit-addons' ),
                ],
            ],
            'thirdparty' => array(
                'id'    => 'amokit_thirdparty_element_tabs',
                'title' => esc_html__( 'Third Party', 'amokit-addons' ),
                'icon'  => 'amokit amokit-extension',
                'content' => [
                    'column' => 3,
                    'title' => __( 'Third Party Widget List', 'amokit-addons' ),
                    'desc'  => __( 'Freely use these elements to create your site. You can enable which you are not using, and, all associated assets will be disable to improve your site loading speed.', 'amokit-addons' ),
                ],
            ),
            'others' => array(
                'id'    => 'amokit_general_tabs',
                'title' => esc_html__( 'Integrations', 'amokit-addons' ),
                'icon'  => 'amokit amokit-others',
                'content' => [
                    'enableall' => false,
                    'title' => __( 'Integrations', 'amokit-addons' ),
                    'desc'  => __( 'Set the fields value to use these features', 'amokit-addons' ),
                ],
            ),
            'advance' => array(
                'id'    => 'amokit_advance_element_tabs',
                'title' => esc_html__( 'Modules', 'amokit-addons' ),
                'icon'  => 'amokit amokit-advance',
                'content' => [
                    'column' => 3,
                    'title' => __( 'Module List', 'amokit-addons' ),
                    'desc'  => __( 'Freely use these elements to create your site. You can enable which you are not using, and, all associated assets will be disable to improve your site loading speed.', 'amokit-addons' ),
                ],
            )
        );

        return apply_filters( 'amokit_admin_fields_sections', $tabs );

    }

    public function get_settings_subtabs(){

        $subtabs = array();

        return apply_filters( 'amokit_admin_fields_sub_sections', $subtabs );
    }

    public function get_registered_settings(){
        $settings = array(
            'amokit_pro_vs_free_tabs' => array(
                
                array(
                    'id'   => 'amokit_pro_vs_free_html',
                    'desc' => __( 'Enter Your ocupation','amokit-addons' ),
                    'type' => 'html',
                    'html' => $this->pro_vs_free_html_tabs()
                ),
                
            ),

            'amokit_element_tabs' => array(

                array(
                    'id'  => 'accordion',
                    'name'  => __( 'Accordion', 'amokit-addons' ),
                    'type'  => 'element',
                    'default' => 'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'animatesectiontitle',
                    'name'  => __( 'Animate Heading', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'addbanner',
                    'name'  => __( 'Ads Banner', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'specialadsbanner',
                    'name'  => __( 'Special Day Offer', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'blockquote',
                    'name'  => __( 'Blockquote', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'brandlogo',
                    'name'  => __( 'Brands', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                
                array(
                    'id'  => 'businesshours',
                    'name'  => __( 'Business Hours', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'button',
                    'name'  => __( 'Button', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'calltoaction',
                    'name'  => __( 'Call To Action', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'carousel',
                    'name'  => __( 'Carousel', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'countdown',
                    'name'  => __( 'Countdown', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'counter',
                    'name'  => __( 'Counter', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'customevent',
                    'name'  => __( 'Custom Event', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                
                array(
                    'id'  => 'dualbutton',
                    'name'  => __( 'Double Button', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                
                array(
                    'id'  => 'dropcaps',
                    'name'  => __( 'Dropcaps', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'flipbox',
                    'name'  => __( 'Flip Box', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'galleryjustify',
                    'name'  => __( 'Gallery Justify', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'googlemap',
                    'name'  => __( 'Google Map', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'imagecomparison',
                    'name'  => __( 'Image Comparison', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                
                array(
                    'id'  => 'imagegrid',
                    'name'  => __( 'Image Grid', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                
                array(
                    'id'  => 'imagemagnifier',
                    'name'  => __( 'Image Magnifier', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                
                array(
                    'id'  => 'imagemarker',
                    'name'  => __( 'Image Marker', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                
                array(
                    'id'  => 'imagemasonry',
                    'name'  => __( 'Image Masonry', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                
                array(
                    'id'  => 'inlinemenu',
                    'name'  => __( 'Inline Navigation', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'instagram',
                    'name'  => __( 'Instagram', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'lightbox',
                    'name'  => __( 'Light Box', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'modal',
                    'name'  => __( 'Modal', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'newtsicker',
                    'name'  => __( 'News Ticker', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                
                array(
                    'id'  => 'notify',
                    'name'  => __( 'Notify', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'offcanvas',
                    'name'  => __( 'Offcanvas', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'panelslider',
                    'name'  => __( 'Panel Slider', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'popover',
                    'name'  => __( 'Popover', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'postcarousel',
                    'name'  => __( 'Post carousel', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'postgrid',
                    'name'  => __( 'Post Grid', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'postgridtab',
                    'name'  => __( 'Post Grid Tab', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'postslider',
                    'name'  => __( 'Post Slider', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'pricinglistview',
                    'name'  => __( 'Pricing List View', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'pricingtable',
                    'name'  => __( 'Pricing Table', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'progressbar',
                    'name'  => __( 'Progress Bar', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'scrollimage',
                    'name'  => __( 'Scroll Image', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'scrollnavigation',
                    'name'  => __( 'Scroll Navigation', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'search',
                    'name'  => __( 'Search', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'sectiontitle',
                    'name'  => __( 'Section Title', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'service',
                    'name'  => __( 'Service', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                
                array(
                    'id'  => 'singlepost',
                    'name'  => __( 'Single Post', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                
                array(
                    'id'  => 'thumbgallery',
                    'name'  => __( 'Slider Thumbnail Gallery', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'socialshere',
                    'name'  => __( 'Social Share', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'switcher',
                    'name'  => __( 'Switcher', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'tabs',
                    'name'  => __( 'Tabs', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'datatable',
                    'name'  => __( 'Data Table', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'teammember',
                    'name'  => __( 'Team Member', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'testimonial',
                    'name'  => __( 'Testimonial', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'testimonialgrid',
                    'name'  => __( 'Testimonial Grid', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'toggle',
                    'name'  => __( 'Toggle', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'tooltip',
                    'name'  => __( 'Tooltip', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'twitterfeed',
                    'name'  => __( 'Twitter Feed', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'userloginform',
                    'name'  => __( 'User Login Form', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'userregisterform',
                    'name'  => __( 'User Register Form', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'verticletimeline',
                    'name'  => __( 'Verticle Timeline', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'videoplayer',
                    'name'  => __( 'Video Player', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'workingprocess',
                    'name'  => __( 'Working Process', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'errorcontent',
                    'name'  => __( '404 Content', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'template_selector',
                    'name'  => __( 'Remote Template', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'weather',
                    'name'  => __( 'Weather', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'on',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'audio_player',
                    'name'  => __( 'Audio Player', 'amokit-addons' ),
                    'type'  => 'element',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                    'default'=> 'off',
                ),
                array(
                    'id'  => 'calendly',
                    'name'  => __( 'Calendly', 'amokit-addons' ),
                    'type'  => 'element',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                    'default'=> 'on',
                ),

                // pro addon list
                array(
                    'id'  => 'info_boxp',
                    'name'  => __( 'Info Box', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'lottiep',
                    'name'  => __( 'Lottie', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'event_calendarp',
                    'name'  => __( 'Event Calendar', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'category_listp',
                    'name'  => __( 'Category List', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'pricing_menup',
                    'name'  => __( 'Pricing Menu', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'feature_listp',
                    'name'  => __( 'Feature List', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'social_network_iconsp',
                    'name'  => __( 'Social Network Icons', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'taxonomy_termsp',
                    'name'  => __( 'Taxonomy Terms', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'background_switcherp',
                    'name'  => __( 'Background Switcher', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'breadcrumbsp',
                    'name'  => __( 'Breadcrumbs', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'page_listp',
                    'name'  => __( 'Page List', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'icon_boxp',
                    'name'  => __( 'Icon Box', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'team_carouselp',
                    'name'  => __( 'Team Carousel', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'interactive_promop',
                    'name'  => __( 'Interactive Promo', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'facebook_reviewp',
                    'name'  => __( 'Facebook Review', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'whatsapp_chatp',
                    'name'  => __( 'WhatsApp Chat', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'filterable_galleryp',
                    'name'  => __( 'Filterable Gallery', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'event_boxp',
                    'name'  => __( 'Event Box', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'chartp',
                    'name'  => __( 'Chart', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'post_timelinep',
                    'name'  => __( 'Post Timeline', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'post_masonryp',
                    'name'  => __( 'Post Masonry', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'source_codep',
                    'name'  => __( 'Source Code', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'threesixty_rotationp',
                    'name'  => __( '360 Rotation', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'pricing_table_flip_boxp',
                    'name'  => __( 'Pricing Table Flip Box', 'amokit-addons' ),
                    'type'  => 'element',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                    'default'=>'off',
                    'is_pro' => true,
                ),
                array(
                    'id'  => 'flip_switcher_pricing_tablep',
                    'name'  => __( 'Flip Switcher Pricing Table', 'amokit-addons' ),
                    'type'  => 'element',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                    'default'=>'off',
                    'is_pro' => true,
                ),
                array(
                    'id'  => 'dynamic_galleryp',
                    'name'  => __( 'Dynamic Gallery', 'amokit-addons' ),
                    'type'  => 'element',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                    'default'=>'off',
                    'is_pro' => true,
                ),
                array(
                    'id'  => 'advanced_sliderp',
                    'name'  => __( 'Advanced Slider', 'amokit-addons' ),
                    'type'  => 'element',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                    'default'=>'off',
                    'is_pro' => true,
                ),
                array(
                    'id'  => 'flip_carouselp',
                    'name'  => __( 'Flip Carousel', 'amokit-addons' ),
                    'type'  => 'element',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                    'default'=>'off',
                    'is_pro' => true,
                ),
                array(
                    'id'  => 'interactive_circle_infographicp',
                    'name'  => __( 'Interactive Circle Infographic', 'amokit-addons' ),
                    'type'  => 'element',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                    'default'=>'off',
                    'is_pro' => true,
                ),
                array(
                    'id'  => 'copy_coupon_codep',
                    'name'  => __( 'Copy Coupon Code', 'amokit-addons' ),
                    'type'  => 'element',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                    'default'=>'off',
                    'is_pro' => true,
                ),
                array(
                    'id'  => 'video_galleryp',
                    'name'  => __( 'Video Gallery', 'amokit-addons' ),
                    'type'  => 'element',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                    'default'=> 'off',
                    'is_pro' => true,
                ),
                array(
                    'id'  => 'video_playlistp',
                    'name'  => __( 'Video Palylist', 'amokit-addons' ),
                    'type'  => 'element',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                    'default'=> 'off',
                    'is_pro' => true,
                ),
                array(
                    'id'  => 'blob_shapep',
                    'name'  => __( 'Blob Shape', 'amokit-addons' ),
                    'type'  => 'element',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                    'default'=> 'off',
                    'is_pro' => true,
                ),
            ),

            'amokit_gutenberg_tabs' => [
                'blocks' => [
                    [
                        'id'  => 'accordion',
                        'name'  => __( 'Accordion', 'amokit-addons' ),
                        'type'  => 'element',
                        'label_on' => __( 'On', 'amokit-addons' ),
                        'label_off' => __( 'Off', 'amokit-addons' ),
                        'default'=>'off',
                        'is_pro' => false,
                    ],
                    [
                        'id'  => 'brand',
                        'name'  => __( 'Brand', 'amokit-addons' ),
                        'type'  => 'element',
                        'label_on' => __( 'On', 'amokit-addons' ),
                        'label_off' => __( 'Off', 'amokit-addons' ),
                        'default'=>'off',
                        'is_pro' => false,
                    ],
                    [
                        'id'  => 'buttons',
                        'name'  => __( 'Buttons', 'amokit-addons' ),
                        'type'  => 'element',
                        'label_on' => __( 'On', 'amokit-addons' ),
                        'label_off' => __( 'Off', 'amokit-addons' ),
                        'default'=>'off',
                        'is_pro' => false,
                    ],
                    [
                        'id'  => 'cta',
                        'name'  => __( 'Call To Action', 'amokit-addons' ),
                        'type'  => 'element',
                        'label_on' => __( 'On', 'amokit-addons' ),
                        'label_off' => __( 'Off', 'amokit-addons' ),
                        'default'=>'off',
                        'is_pro' => false,
                    ],
                    [
                        'id'  => 'image-grid',
                        'name'  => __( 'Image Grid', 'amokit-addons' ),
                        'type'  => 'element',
                        'label_on' => __( 'On', 'amokit-addons' ),
                        'label_off' => __( 'Off', 'amokit-addons' ),
                        'default'=>'off',
                        'is_pro' => false,
                    ],
                    [
                        'id'  => 'info-box',
                        'name'  => __( 'Info Box', 'amokit-addons' ),
                        'type'  => 'element',
                        'label_on' => __( 'On', 'amokit-addons' ),
                        'label_off' => __( 'Off', 'amokit-addons' ),
                        'default'=>'off',
                        'is_pro' => false,
                    ],
                    [
                        'id'  => 'section-title',
                        'name'  => __( 'Section Title', 'amokit-addons' ),
                        'type'  => 'element',
                        'label_on' => __( 'On', 'amokit-addons' ),
                        'label_off' => __( 'Off', 'amokit-addons' ),
                        'default'=>'off',
                        'is_pro' => false,
                    ],
                    [
                        'id'  => 'tab',
                        'name'  => __( 'Tabs', 'amokit-addons' ),
                        'type'  => 'element',
                        'label_on' => __( 'On', 'amokit-addons' ),
                        'label_off' => __( 'Off', 'amokit-addons' ),
                        'default'=>'off',
                        'is_pro' => false,
                    ],
                    [
                        'id'  => 'team',
                        'name'  => __( 'Team', 'amokit-addons' ),
                        'type'  => 'element',
                        'label_on' => __( 'On', 'amokit-addons' ),
                        'label_off' => __( 'Off', 'amokit-addons' ),
                        'default'=>'off',
                        'is_pro' => false,
                    ],
                    [
                        'id'  => 'testimonial',
                        'name'  => __( 'Testimonial', 'amokit-addons' ),
                        'type'  => 'element',
                        'label_on' => __( 'On', 'amokit-addons' ),
                        'label_off' => __( 'Off', 'amokit-addons' ),
                        'default'=>'off',
                        'is_pro' => false,
                    ],
                ]
            ],

            'amokit_general_tabs' => array(
                array(
                    'id'  => 'google_map_api_key',
                    'name' => __( 'Google Map API Key', 'amokit-addons' ),
                    'desc'  => __( 'Go to <a href="https://developers.google.com/maps/documentation/javascript/get-api-key" target="_blank">https://developers.google.com</a> and generate the API key.', 'amokit-addons' ),
                    'placeholder' => __( 'Google Map API key', 'amokit-addons' ),
                    'type' => 'text',
                ),

                array(
                    'id'  => 'weather_map_api_key',
                    'name' => __( 'Weather Map API Key', 'amokit-addons' ),
                    'desc'  => __( 'Please enter a OpenWeatherMaps API key. OpenWeather is a weather provider service which is capable of delivering all the necessary weather information for any location on the globe.To create API key, go to this link <a href="https://openweathermap.org/appid" target="_blank">OpenWeather</a>.', 'amokit-addons' ),
                    'placeholder' => __( 'Weather Map API key', 'amokit-addons' ),
                    'type' => 'text',
                ),

                array(
                    'id'    => 'errorpage',
                    'name'   => __( 'Select 404 Page.', 'amokit-addons' ),
                    'desc'    => __( 'You can select 404 page from here.', 'amokit-addons' ),
                    'type'    => 'select',
                    'default' => '0',
                    'options' => amokit_post_name( 'page', -1 )
                ),

                array(
                    'id'  => 'loadpostlimit',
                    'name' => __( 'Load Post in Elementor Addons', 'amokit-addons' ),
                    'desc'  => wp_kses_post( 'Load Post in Elementor Addons' ),
                    'min'               => 1,
                    'max'               => 1000,
                    'step'              => '1',
                    'type'              => 'number',
                    'default'           => '20',
                    'sanitize_callback' => 'floatval',
                ),

            ),

            'amokit_advance_element_tabs' => array(
                array(
                    'id'  => 'themebuilder',
                    'name'  => __( 'Theme Builder', 'amokit-addons' ),
                    'type'  => 'module',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                    'section'  => 'amokit_themebuilder_module_settings',
                    'setting_fields' => array(
                        array(
                            'id'  => 'themebuilder_enable',
                            'name' => esc_html__( 'Enable / Disable' ),
                            'desc'  => esc_html__( 'You can enable / disable Theme Builder from  here.', 'amokit-addons' ),
                            'type'  => 'checkbox',
                            'default' => 'off',
                            'class' => 'amokit-action-field-left',
                            'label_on' => esc_html__( 'On', 'amokit-addons' ),
                            'label_off' => esc_html__( 'Off', 'amokit-addons' ),
                        ),
                        array(
                            'id'    => 'single_blog_page',
                            'name'   => __( 'Single Blog Template.', 'amokit-addons' ),
                            'desc'    => __( 'You can select Single blog page from here.', 'amokit-addons' ),
                            'type'    => 'select',
                            'default' => '0',
                            'options' => amokit_elementor_template(),
                            'condition' => [ ['condition_key' => 'themebuilder_enable', 'condition_value' => 'on'] ]
                        ),
                        array(
                            'id'    => 'archive_blog_page',
                            'name'   => __( 'Blog Template.', 'amokit-addons' ),
                            'desc'    => __( 'You can select blog page from here.', 'amokit-addons' ),
                            'type'    => 'select',
                            'default' => '0',
                            'options' => amokit_elementor_template(),
                            'condition' => [ ['condition_key' => 'themebuilder_enable', 'condition_value' => 'on'] ]
                        ),
                        array(
                            'id'    => 'header_page',
                            'name'   => __( 'Header Template.', 'amokit-addons' ),
                            'desc'    => __( 'You can select header template from here.', 'amokit-addons' ),
                            'type'    => 'select',
                            'default' => '0',
                            'options' => amokit_elementor_template(),
                            'condition' => [ ['condition_key' => 'themebuilder_enable', 'condition_value' => 'on'] ]
                        ),
                        array(
                            'id'    => 'footer_page',
                            'name'   => __( 'Footer Template.', 'amokit-addons' ),
                            'desc'    => __( 'You can select footer template from here.', 'amokit-addons' ),
                            'type'    => 'select',
                            'default' => '0',
                            'options' => amokit_elementor_template(),
                            'condition' => [ ['condition_key' => 'themebuilder_enable', 'condition_value' => 'on'] ]
                        ),
                        array(
                            'id'    => 'search_pagep',
                            'name'   => __( 'Search Page Template.', 'amokit-addons' ),
                            'desc'    => __( 'You can select search page from here.', 'amokit-addons' ),
                            'type'    => 'select',
                            'default' => 'select',
                            'options' => array(
                                'select'=>'Select Template',
                            ),
                            'is_pro' => true,
                            'condition' => [ ['condition_key' => 'themebuilder_enable', 'condition_value' => 'on'] ]
                        ),
                        array(
                            'id'    => 'error_pagep',
                            'name'   => __( '404 Page Template.', 'amokit-addons' ),
                            'desc'    => __( 'You can select 404 page from here. <span>( Pro )</span>', 'amokit-addons' ),
                            'type'    => 'select',
                            'default' => 'select',
                            'options' => array(
                                'select'=>'Select Template',
                            ),
                            'is_pro' => true,
                            'condition' => [ ['condition_key' => 'themebuilder_enable', 'condition_value' => 'on'] ]
                        ),
                        array(
                            'id'    => 'coming_soon_pagep',
                            'name'   => __( 'Coming Soon Page Template.', 'amokit-addons' ),
                            'desc'    => __( 'You can select coming soon page from here.', 'amokit-addons' ),
                            'type'    => 'select',
                            'default' => 'select',
                            'options' => array(
                                'select'=>'Select Template',
                            ),
                            'is_pro' => true,
                            'condition' => [ ['condition_key' => 'themebuilder_enable', 'condition_value' => 'on'] ]
                        ),
                    ),
                ),
                array(
                    'id'  => 'salenotification',
                    'name'  => __( 'Sales Notification', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),

                array(
                    'id'  => 'megamenubuilder',
                    'name'  => __( 'Menu Builder', 'amokit-addons' ),
                    'type'  => 'module',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                    'section'  => 'amokit_megamenu_module_settings',
                    'setting_fields' => array(
                        array(
                            'id'  => 'megamenubuilder_enable',
                            'name' => esc_html__( 'Enable / Disable' ),
                            'desc'  => esc_html__( 'You can enable / disable Menu Builder from  here.', 'amokit-addons' ),
                            'type'  => 'checkbox',
                            'default' => 'off',
                            'class' => 'amokit-action-field-left',
                            'label_on' => esc_html__( 'On', 'amokit-addons' ),
                            'label_off' => esc_html__( 'Off', 'amokit-addons' ),
                        ),

                        array(
                            'id'    => 'menu_items_color',
                            'name'   => __( 'Menu Items Color', 'amokit-addons' ),
                            'desc'    => __( 'Set the Menu Items Color.', 'amokit-addons' ),
                            'class' => 'amokit-action-field-left',
                            'type'    => 'color',
                            'default' => '',
                            'condition' => [['condition_key' => 'megamenubuilder_enable', 'condition_value' => 'on']]
                        ),
                        array(
                            'id'    => 'menu_items_hover_color',
                            'name'   => __( 'Menu Items Hover Color', 'amokit-addons' ),
                            'desc'    => __( 'Set the Menu Items Hover Color.', 'amokit-addons' ),
                            'class' => 'amokit-action-field-left',
                            'type'    => 'color',
                            'default' => '',
                            'condition' => [['condition_key' => 'megamenubuilder_enable', 'condition_value' => 'on']]
                        ),
                        array(
                            'id'  => 'sub_menu_width',
                            'name' => __( 'Sub Menu Width', 'amokit-addons' ),
                            'desc'  => __( 'Specify the width of the Sub Menu (px).', 'amokit-addons' ),
                            'min'               => 0,
                            'max'               => 1000,
                            'step'              => '1',
                            'type'              => 'number',
                            'default'           => '200',
                            'sanitize_callback' => 'floatval',
                            'condition' => [['condition_key' => 'megamenubuilder_enable', 'condition_value' => 'on']]
                        ),
                        array(
                            'id'    => 'sub_menu_bg_color',
                            'name'   => __( 'Sub Menu Background Color', 'amokit-addons' ),
                            'desc'    => __( 'Set the Sub Menu Background Color.', 'amokit-addons' ),
                            'class' => 'amokit-action-field-left',
                            'type'    => 'color',
                            'default' => '',
                            'condition' => [['condition_key' => 'megamenubuilder_enable', 'condition_value' => 'on']]
                        ),
                        array(
                            'id'    => 'sub_menu_items_color',
                            'name'   => __( 'Sub Menu Items Color', 'amokit-addons' ),
                            'desc'    => __( 'Set the Sub Menu Items Color.', 'amokit-addons' ),
                            'class' => 'amokit-action-field-left',
                            'type'    => 'color',
                            'default' => '',
                            'condition' => [['condition_key' => 'megamenubuilder_enable', 'condition_value' => 'on']]
                        ),
                        array(
                            'id'    => 'sub_menu_items_hover_color',
                            'name'   => __( 'Sub Menu Items Hover Color', 'amokit-addons' ),
                            'desc'    => __( 'Set the Sub Menu Items Hover Color.', 'amokit-addons' ),
                            'class' => 'amokit-action-field-left',
                            'type'    => 'color',
                            'default' => '',
                            'condition' => [['condition_key' => 'megamenubuilder_enable', 'condition_value' => 'on']]
                        ),
                        array(
                            'id'  => 'mega_menu_width',
                            'name' => __( 'Mega Menu Width', 'amokit-addons' ),
                            'desc'  => __( 'Specify the Mega Menu Width (px)', 'amokit-addons' ),
                            'min'               => 0,
                            'max'               => 2000,
                            'step'              => '1',
                            'type'              => 'number',
                            'default'           => '',
                            'sanitize_callback' => 'floatval',
                            'condition' => [['condition_key' => 'megamenubuilder_enable', 'condition_value' => 'on']]
                        ),
                        array(
                            'id'    => 'mega_menu_bg_color',
                            'name'   => __( 'Mega Menu Background Color', 'amokit-addons' ),
                            'desc'    => __( 'Set the Mega Menu Background Color.', 'amokit-addons' ),
                            'class' => 'amokit-action-field-left',
                            'type'    => 'color',
                            'default' => '',
                            'condition' => [['condition_key' => 'megamenubuilder_enable', 'condition_value' => 'on']]
                        )
                    ),
                ),

                array(
                    'id'  => 'postduplicator',
                    'name'  => __( 'Post Duplicator', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                
                array(
                    'id'  => 'wrapperlink',
                    'name'  => __( 'Wrapper Link', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                
                array(
                    'id'  => 'floating_effects',
                    'name'  => __( 'Floating Effects', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                
                array(
                    'id'  => 'amokit_rpbar',
                    'name'  => __( 'Reading Progress Bar', 'amokit-addons' ),
                    'type'  => 'module',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                    'section'  => 'amokit_rpbar_module_settings',
                    'setting_fields' => array(
                        array(
                            'id'  => 'rpbar_enable',
                            'name' => __( 'Enable/Disable', 'amokit-addons' ),
                            'desc'  => __( 'You can enable/disable the Reading Progress Bar from here.', 'amokit-addons' ),
                            'type'  => 'checkbox',
                            'default' => 'off',
                            'class' => 'amokit-action-field-left',
                            'label_on' => __( 'On', 'amokit-addons' ),
                            'label_off' => __( 'Off', 'amokit-addons' ),
                        ),
                        array(
                            'id'  => 'rpbar_globalp',
                            'name' => __( 'Enable/Disable Global', 'amokit-addons' ),
                            'desc'  => __( 'Enable Reading Progress Bar Globally.' , 'amokit-addons'),
                            'type'  => 'checkbox',
                            'default' => 'off',
                            'class' => 'amokit-action-field-left',
                            'label_on' => __( 'On', 'amokit-addons' ),
                            'label_off' => __( 'Off', 'amokit-addons' ),
                            'is_pro' => true,
                        ),

                    )
                ),
                array(
                    'id'  => 'amokit_stt',
                    'name'  => __( 'Scroll To Top', 'amokit-addons' ),
                    'type'  => 'module',
                    'default'=>'off',
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                    'section'  => 'amokit_stt_module_settings',
                    'setting_fields' => array(
                        array(
                            'id'  => 'stt_enable',
                            'name' => __( 'Enable/Disable', 'amokit-addons' ),
                            'desc'  => __( 'You can enable/disable Scroll To Top from here.', 'amokit-addons' ),
                            'type'  => 'checkbox',
                            'default' => 'off',
                            'class' => 'amokit-action-field-left',
                            'label_on' => __( 'On', 'amokit-addons' ),
                            'label_off' => __( 'Off', 'amokit-addons' ),
                        ),
                        array(
                            'id'  => 'stt_globalp',
                            'name' => __( 'Enable/Disable Global', 'amokit-addons' ),
                            'desc'  => __( 'Enable Scroll To Top Globally.', 'amokit-addons' ),
                            'type'  => 'checkbox',
                            'default' => 'off',
                            'class' => 'amokit-action-field-left',
                            'label_on' => __( 'On', 'amokit-addons' ),
                            'label_off' => __( 'Off', 'amokit-addons' ),
                            'is_pro' => true,
                        ),
                    )
                ),
               
                array(
                    'id'  => 'crossdomaincpp',
                    'name'  => __( 'Cross Domain Copy Paste', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'parallax_modulep',
                    'name'  => __( 'Parallax', 'amokit-addons' ),
                    'type'  => 'element',
                    'default' => 'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'particles_modulep',
                    'name'  => __( 'Particles', 'amokit-addons' ),
                    'type'  => 'element',
                    'default' => 'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'd_conditional_modulep',
                    'name'  => __( 'Conditional Display', 'amokit-addons' ),
                    'type'  => 'element',
                    'default' => 'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'advanced_sticky_modulep',
                    'name'  => __( 'Advanced Sticky', 'amokit-addons' ),
                    'type'  => 'element',
                    'default' => 'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
                array(
                    'id'  => 'custom_css_modulep',
                    'name'  => __( 'Custom CSS', 'amokit-addons' ),
                    'type'  => 'element',
                    'default'=>'off',
                    'is_pro' => true,
                    'label_on' => __( 'On', 'amokit-addons' ),
                    'label_off' => __( 'Off', 'amokit-addons' ),
                ),
            ),

        );

        $settings['amokit_themebuilder_element_tabs'] = array(

            array(
                'id'  => 'bl_post_title',
                'name'  => __( 'Post Title', 'amokit-addons' ),
                'type'    => 'element',
                'default' => 'on',
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ),

            array(
                'id'  => 'bl_post_featured_image',
                'name'  => __( 'Post Featured Image', 'amokit-addons' ),
                'type'    => 'element',
                'default' => 'on',
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ),

            array(
                'id'  => 'bl_post_meta_info',
                'name'  => __( 'Post Meta Info', 'amokit-addons' ),
                'type'    => 'element',
                'default' => 'on',
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ),

            array(
                'id'  => 'bl_post_excerpt',
                'name'  => __( 'Post Excerpt', 'amokit-addons' ),
                'type'    => 'element',
                'default' => 'on',
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ),

            array(
                'id'  => 'bl_post_content',
                'name'  => __( 'Post Content', 'amokit-addons' ),
                'type'    => 'element',
                'default' => 'on',
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ),

            array(
                'id'  => 'bl_post_comments',
                'name'  => __( 'Post Comments', 'amokit-addons' ),
                'type'    => 'element',
                'default' => 'on',
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ),

            array(
                'id'  => 'bl_post_search_form',
                'name'  => __( 'Post Search Form', 'amokit-addons' ),
                'type'    => 'element',
                'default' => 'on',
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ),

            array(
                'id'  => 'bl_post_archive',
                'name'  => __( 'Archive Posts', 'amokit-addons' ),
                'type'    => 'element',
                'default' => 'on',
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ),

            array(
                'id'  => 'bl_post_archive_title',
                'name'  => __( 'Archive Title', 'amokit-addons' ),
                'type'    => 'element',
                'default' => 'on',
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ),
            
            array(
                'id'  => 'bl_page_title',
                'name'  => __( 'Page Title', 'amokit-addons' ),
                'type'    => 'element',
                'default' => 'on',
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ),

            array(
                'id'  => 'bl_site_title',
                'name'  => __( 'Site Title', 'amokit-addons' ),
                'type'    => 'element',
                'default' => 'on',
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ),

            array(
                'id'  => 'bl_site_logo',
                'name'  => __( 'Site Logo', 'amokit-addons' ),
                'type'    => 'element',
                'default' => 'on',
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ),

            array(
                'id'  => 'bl_nav_menu',
                'name'  => __( 'Nav Menu', 'amokit-addons' ),
                'type'    => 'element',
                'default' => 'on',
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ),

            array(
                'id'  => 'bl_post_author_info',
                'name'  => __( 'Author Info', 'amokit-addons' ),
                'type'    => 'element',
                'default' => 'on',
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ),

            array(
                'id'  => 'bl_social_sharep',
                'name'  => __( 'Social Share', 'amokit-addons' ),
                'type'    => 'element',
                'default' => 'off',
                'is_pro' => true,
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ),

            array(
                'id'  => 'bl_print_pagep',
                'name'  => __( 'Print Page', 'amokit-addons' ),
                'type'    => 'element',
                'default' => 'off',
                'is_pro' => true,
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ),

            array(
                'id'  => 'bl_view_counterp',
                'name'  => __( 'View Counter', 'amokit-addons' ),
                'type'    => 'element',
                'default' => 'off',
                'is_pro' => true,
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ),

            array(
                'id'  => 'bl_post_navigationp',
                'name'  => __( 'Post Navigation', 'amokit-addons' ),
                'type'    => 'element',
                'default' => 'off',
                'is_pro' => true,
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ),

            array(
                'id'  => 'bl_related_postp',
                'name'  => __( 'Related Post', 'amokit-addons' ),
                'type'    => 'element',
                'default' => 'off',
                'is_pro' => true,
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ),

            array(
                'id'  => 'bl_popular_postp',
                'name'  => __( 'Popular Post', 'amokit-addons' ),
                'type'    => 'element',
                'default' => 'off',
                'is_pro' => true,
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ),


        );

        // Post Duplicator Condition
        if( amokit_get_option( 'postduplicator', 'amokit_advance_element_tabs', 'off' ) === 'on' ){
            $post_types = amokit_get_post_types( array('defaultadd'=>'all') );
            if ( did_action( 'elementor/loaded' ) && defined( 'ELEMENTOR_VERSION' ) ) {
                $post_types['elementor_library'] = esc_html__( 'Templates', 'amokit-addons' );
            }
            $settings['amokit_general_tabs'][] = [
                'id'    => 'postduplicate_condition',
                'name'   => __( 'Post Duplicator Condition', 'amokit-addons' ),
                'desc'    => __( 'You can enable duplicator for individual post.', 'amokit-addons' ),
                'type'    => 'multiselect',
                'default' => '',
                'options' => $post_types,
            ];
        }

        $third_party_element = array();
        // Third Party Addons
        if( is_plugin_active('bbpress/bbpress.php') ) {
            $third_party_element['amokit_thirdparty_element_tabs'][] = [
                'id'    => 'bbpress',
                'name'    => __( 'bbPress', 'amokit-addons' ),
                'type'    => 'element',
                'default' => "on",
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ];
        }

        if( is_plugin_active('booked/booked.php') ) {
            $third_party_element['amokit_thirdparty_element_tabs'][] = [
                'id'    => 'bookedcalender',
                'name'    => __( 'Booked Calender', 'amokit-addons' ),
                'type'    => 'element',
                'default' => "on",
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ];
        }

        if( is_plugin_active('buddypress/bp-loader.php') ) {
            $third_party_element['amokit_thirdparty_element_tabs'][] = [
                'id'    => 'buddypress',
                'name'    => __( 'BuddyPress', 'amokit-addons' ),
                'type'    => 'element',
                'default' => "on",
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ];
        }

        if( is_plugin_active('caldera-forms/caldera-core.php') ) {
            $third_party_element['amokit_thirdparty_element_tabs'][] = [
                'id'    => 'calderaform',
                'name'    => __( 'Caldera Form', 'amokit-addons' ),
                'type'    => 'element',
                'default' => "on",
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ];
        }

        if( is_plugin_active('contact-form-7/wp-contact-form-7.php') ) {
            $third_party_element['amokit_thirdparty_element_tabs'][] = [
                'id'    => 'contactform',
                'name'    => __( 'Contact form 7', 'amokit-addons' ),
                'type'    => 'element',
                'default' => "on",
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ];
        }

        if( is_plugin_active('download-monitor/download-monitor.php') ) {
            $third_party_element['amokit_thirdparty_element_tabs'][] = [
                'id'    => 'downloadmonitor',
                'name'    => __( 'Download Monitor', 'amokit-addons' ),
                'type'    => 'element',
                'default' => "on",
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ];
        }

        if( is_plugin_active('easy-digital-downloads/easy-digital-downloads.php') ) {
            $third_party_element['amokit_thirdparty_element_tabs'][] = [
                'id'    => 'easydigitaldownload',
                'name'    => __( 'Easy Digital Downloads', 'amokit-addons' ),
                'type'    => 'element',
                'default' => "on",
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ];
        }

        if( is_plugin_active('gravityforms/gravityforms.php') ) {
            $third_party_element['amokit_thirdparty_element_tabs'][] = [
                'id'    => 'gravityforms',
                'name'    => __( 'Gravity Forms', 'amokit-addons' ),
                'type'    => 'element',
                'default' => "on",
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ];
        }

        if( is_plugin_active('instagram-feed/instagram-feed.php') ) {
            $third_party_element['amokit_thirdparty_element_tabs'][] = [
                'id'    => 'instragramfeed',
                'name'    => __( 'Instragram Feed', 'amokit-addons' ),
                'type'    => 'element',
                'default' => "on",
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ];
        }

        if( is_plugin_active('wp-job-manager/wp-job-manager.php') ) {
            $third_party_element['amokit_thirdparty_element_tabs'][] = [
                'id'    => 'jobmanager',
                'name'    => __( 'Job Manager', 'amokit-addons' ),
                'type'    => 'element',
                'default' => "on",
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ];
        }

        if( is_plugin_active('LayerSlider/layerslider.php') ) {
            $third_party_element['amokit_thirdparty_element_tabs'][] = [
                'id'    => 'layerslider',
                'name'    => __( 'Job Manager', 'amokit-addons' ),
                'type'    => 'element',
                'default' => "on",
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ];
        }

        if( is_plugin_active('mailchimp-for-wp/mailchimp-for-wp.php') ) {
            $third_party_element['amokit_thirdparty_element_tabs'][] = [
                'id'    => 'mailchimpwp',
                'name'    => __( 'Mailchimp for wp', 'amokit-addons' ),
                'type'    => 'element',
                'default' => "on",
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ];
        }

        if( is_plugin_active('ninja-forms/ninja-forms.php') ) {
            $third_party_element['amokit_thirdparty_element_tabs'][] = [
                'id'    => 'ninjaform',
                'name'    => __( 'Ninja Form', 'amokit-addons' ),
                'type'    => 'element',
                'default' => "on",
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ];
        }

        if( is_plugin_active('quform/quform.php') ) {
            $third_party_element['amokit_thirdparty_element_tabs'][] = [
                'id'    => 'quforms',
                'name'    => __( 'QU Form', 'amokit-addons' ),
                'type'    => 'element',
                'default' => "on",
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ];
        }

        if( is_plugin_active('wpforms-lite/wpforms.php') ) {
            $third_party_element['amokit_thirdparty_element_tabs'][] = [
                'id'    => 'wpforms',
                'name'    => __( 'WP Form', 'amokit-addons' ),
                'type'    => 'element',
                'default' => "on",
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ];
        }

        if( is_plugin_active('revslider/revslider.php') ) {
            $third_party_element['amokit_thirdparty_element_tabs'][] = [
                'id'    => 'revolution',
                'name'    => __( 'Revolution Slider', 'amokit-addons' ),
                'type'    => 'element',
                'default' => "on",
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ];
        }

        if( is_plugin_active('tablepress/tablepress.php') ) {
            $third_party_element['amokit_thirdparty_element_tabs'][] = [
                'id'    => 'tablepress',
                'name'    => __( 'TablePress', 'amokit-addons' ),
                'type'    => 'element',
                'default' => "on",
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ];
        }
    
        if( is_plugin_active('woocommerce/woocommerce.php') ) {
           
            $third_party_element['amokit_thirdparty_element_tabs'][] = [
                'id'    => 'wcaddtocart',
                'name'    => __( 'WC : Add To cart', 'amokit-addons' ),
                'type'    => 'element',
                'default' => "on",
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ];

            $third_party_element['amokit_thirdparty_element_tabs'][] = [
                'id'    => 'categories',
                'name'    => __( 'WC : Categories', 'amokit-addons' ),
                'type'    => 'element',
                'default' => "on",
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ];

            $third_party_element['amokit_thirdparty_element_tabs'][] = [
                'id'    => 'wcpages',
                'name'    => __( 'WC : Pages', 'amokit-addons' ),
                'type'    => 'element',
                'default' => "on",
                'label_on' => __( 'On', 'amokit-addons' ),
                'label_off' => __( 'Off', 'amokit-addons' ),
            ];

        }

        if( empty( $third_party_element ) ){
            $third_party_element['amokit_thirdparty_element_tabs'][] = [
                'id'    => 'noelement',
                'html'    => __( 'No Element Found', 'amokit-addons' ),
                'type'    => 'html',
            ];
        }

        $allFields = array_merge( $settings, $third_party_element );
        return apply_filters( 'amokit_admin_fields', $allFields );

    }

    // General tab
    public function pro_vs_free_html_tabs(){
        ob_start();
        include_once AMOKITOPT_INCLUDES .'/templates/dashboard-general.php';
        return ob_get_clean();
    }

}
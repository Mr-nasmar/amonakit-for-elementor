<div class="amotemplates-templates-area">

    <!-- PopUp Content Start -->
    <div id="amowpt-popup-area" style="display: none;">
        <div class="amotemplate-popupcontent">
            <div class='amowptspinner'></div>
            <div class="amowptmessage" style="display: none;">
                <p></p>
                <span class="amowpt-edit"></span>
            </div>
            <div class="amowptpopupcontent">
                <ul class="amowptemplata-requiredplugins"></ul>
                <p><?php esc_html_e( 'Import template to your Library', 'amokit-addons' ); ?></p>
                <span class="amowptimport-button-dynamic"></span>
                <div class="amopageimportarea">
                    <p> <?php esc_html_e( 'Create a new page from this template', 'amokit-addons' ); ?></p>
                    <input id="amowptpagetitle" type="text" name="amowptpagetitle" placeholder="<?php echo esc_attr_x( 'Enter a Page Name', 'placeholder', 'amokit-addons' ); ?>">
                    <span class="amowptimport-button-dynamic-page"></span>
                </div>
            </div>
        </div>
    </div>
    <!-- PopUp Content End -->

    <div id="amowpt-search-section" class="amowpt-search-section section">
        <div class="container-fluid">
            <form action="#" class="amowpt-search-form">
                <div class="row">

                    <div class="col-md-auto col">
                        <div class="amowpt-demos-select">
                            <select id="amowpt-demos">
                                <option value="templates"><?php esc_html_e( 'Templates', 'amokit-addons' ); ?></option>
                                <option value="blocks"><?php esc_html_e( 'Blocks', 'amokit-addons' ); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-auto col">
                        <div class="amowpt-builder-select">
                            <select id="amowpt-builder">
                                <option value="all"><?php esc_html_e( 'All Builders', 'amokit-addons' ); ?></option>
                                <option value="elementor"><?php esc_html_e( 'Elementor', 'amokit-addons' ); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="col-auto mr-auto">
                        <input id="amowpt-search-field" type="text" placeholder="<?php esc_attr_e( 'Search..', 'amokit-addons' );?>">
                    </div>
                    <div class="col-auto amo-tempate-sync-wrapper">
                        <div class="amo-template-library-page-sync">
                            <i class="eicon-sync" aria-hidden="true" title="<?php esc_attr_e( 'Sync Library', 'amokit-addons' ); ?>"></i>
                            <span class="elementor-screen-only"><?php echo esc_html__( 'Sync Library', 'amokit-addons' ); ?></span>
                        </div>
                        <div class="amowpt-type-select">
                            <select id="amowpt-type">
                                <option value="all"><?php esc_html_e( 'ALL', 'amokit-addons' ); ?></option>
                                <option value="free"><?php esc_html_e( 'Free', 'amokit-addons' ); ?></option>
                                <option value="pro"><?php esc_html_e( 'Pro', 'amokit-addons' ); ?></option>
                            </select>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div id="amowpt-project-section" class="amowpt-project-section section">
        <div id="amowpt-project-grid" class="amowpt-project-grid row" style="overflow: hidden;">
            <h2 class="amowpt-project-message"><span class="amowpt-pro-loading2"></span></h2>
        </div>
        <div id="amowpt-load-more-project" class="text-center"></div>
    </div>

    <div id="amowpt-group-section">
        <div id="amowpt-group-bar" class="amowpt-group-bar">
            <span id="amowpt-group-close" class="back"><i>&#8592;</i> <?php esc_html_e( 'Back to Library', 'amokit-addons' ); ?></span>
            <h3 id="amowpt-group-name" class="title"></h3>
        </div>

        <div id="amowpt-group-grid" class="row"></div>
        <a href="#top" class="amowpt-groupScrollToTop"><?php echo esc_html__( 'Top', 'amokit-addons' );?></a>
    </div>

    <a href="#top" class="amowpt-scrollToTop"><?php echo esc_html__( 'Top', 'amokit-addons' );?></a>

</div>
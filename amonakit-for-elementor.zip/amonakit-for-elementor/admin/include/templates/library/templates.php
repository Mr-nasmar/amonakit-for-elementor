 <?php
	/**
	 * Template library templates
	 */
	if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>

<script type="text/template" id="tmpl-amokit-template-library-header-actions">
	<div id="amokit-template-library-header-sync" class="elementor-templates-modal__header__item">
		<i class="eicon-sync" aria-hidden="true" title="<?php esc_attr_e( 'Sync Library', 'amokit-addons' ); ?>"></i>
		<span class="elementor-screen-only"><?php echo esc_html__( 'Sync Library', 'amokit-addons' ); ?></span>
	</div>
</script>

<script type="text/template" id="tmpl-amokit-template-library-logo">
    <span class="tmpl-amokit-template-library-logo-area">
        <img src="<?php echo esc_url(AMONAKIT_ADDONS_PL_URL .'admin/assets/images/menu-icon.svg'); ?>" />
    </span>
    <span class="tmpl-amokit-template-library-logo-title">{{{ title }}}</span>
</script>

<script type="text/template" id="tmpl-amokit-template-library-header-menu">
	<# _.each( tabs, function( args, tab ) { var activeClass = args.active ? 'elementor-active' : ''; #>
	<div class="elementor-component-tab elementor-template-library-menu-item {{activeClass}}" data-tab="{{{ tab }}}">{{{ args.title }}}</div>
	<# } ); #>
</script>

<script type="text/template" id="tmpl-amokit-template-library-header-menu-responsive">
	<div class="elementor-component-tab amokit-template-library-responsive-menu-item elementor-active" data-tab="desktop">
		<i class="eicon-device-desktop" aria-hidden="true" title="<?php esc_attr_e( 'Desktop view', 'amokit-addons' ); ?>"></i>
		<span class="elementor-screen-only"><?php esc_html_e( 'Desktop view', 'amokit-addons' ); ?></span>
	</div>
	<div class="elementor-component-tab amokit-template-library-responsive-menu-item" data-tab="tab">
		<i class="eicon-device-tablet" aria-hidden="true" title="<?php esc_attr_e( 'Tab view', 'amokit-addons' ); ?>"></i>
		<span class="elementor-screen-only"><?php esc_html_e( 'Tab view', 'amokit-addons' ); ?></span>
	</div>
	<div class="elementor-component-tab amokit-template-library-responsive-menu-item" data-tab="mobile">
		<i class="eicon-device-mobile" aria-hidden="true" title="<?php esc_attr_e( 'Mobile view', 'amokit-addons' ); ?>"></i>
		<span class="elementor-screen-only"><?php esc_html_e( 'Mobile view', 'amokit-addons' ); ?></span>
	</div>
</script>

<script type="text/template" id="tmpl-amokit-template-library-loading">
	<div class="elementor-loader-wrapper">
		<div class="elementor-loader">
			<div class="elementor-loader-boxes">
				<div class="elementor-loader-box"></div>
				<div class="elementor-loader-box"></div>
				<div class="elementor-loader-box"></div>
				<div class="elementor-loader-box"></div>
			</div>
		</div>
		<div class="elementor-loading-title"><?php echo esc_html__( 'Loading', 'amokit-addons' ); ?></div>
	</div>
</script>

<script type="text/template" id="tmpl-amokit-template-library-preview">
    <iframe></iframe>
</script>

<script type="text/template" id="tmpl-amokit-template-library-insert-button">
	<a class="elementor-template-library-template-action amokit-template-library-template-insert elementor-button">
		<i class="eicon-file-download" aria-hidden="true"></i>
		<span class="elementor-button-title"><?php echo esc_html__( 'Insert', 'amokit-addons' ); ?></span>
	</a>
</script>

<script type="text/template" id="tmpl-amokit-template-library-get-pro-button">
	<a class="elementor-template-library-template-action elementor-button elementor-go-pro" href="https://nasdesigns.rf.gd/pricing/" target="_blank">
		<i class="eicon-external-link-square" aria-hidden="true"></i>
		<span class="elementor-button-title"><?php echo esc_html__( 'Go Pro', 'amokit-addons' ); ?></span>
	</a>
</script>

<script type="text/template" id="tmpl-amokit-template-library-header-insert">
	<div id="elementor-template-library-header-preview-insert-wrapper" class="elementor-templates-modal__header__item">
		{{{ amokit.library.getModal().getTemplateActionButton( obj ) }}}
	</div>
</script>

<script type="text/template" id="tmpl-amokit-template-library-header-back">
	<i class="eicon-" aria-hidden="true"></i>
	<span><?php echo esc_html__( 'Back to Library', 'amokit-addons' ); ?></span>
</script>

<script type="text/template" id="tmpl-amokit-template-library-templates">
	<div id="elementor-template-library-toolbar">

		<div id="amokit-template-library-filter-area-wrapper">
			
		</div>

		<div id="elementor-template-library-filter-text-wrapper">
			<label for="amokit-template-library-filter-text" class="elementor-screen-only"><?php esc_html_e( 'Search Templates:', 'amokit-addons' ); ?></label>
			<input id="amokit-template-library-filter-text" placeholder="<?php esc_attr_e( 'Search', 'amokit-addons' ); ?>">
			<i class="eicon-search"></i>
		</div>

	</div>

	<div class="amo-template-library-window">
		<div id="amokit-template-library-list"></div>
	</div>

</script>

<script type="text/template" id="amokit-template-library-template">

	<div class="elementor-template-library-template-body">
		<# if ( 'page' === type ) { #>
			<div class="elementor-template-library-template-screenshot" style="background-image: url({{ thumbnail }});"></div>
		<# } else { #>
			<img class="amo-template-library-thumbnail" src="{{ thumbnail }}">
		<# } #>
		<div class="amo-template-library-preview">
			<i class="eicon-zoom-in-bold" aria-hidden="true"></i>
		</div>
		<# if ( obj.isPro ) { #>
		<span class="amo-template-library-pro-badge"><?php esc_html_e( 'Pro', 'amokit-addons' ); ?></span>
		<# } #>
	</div>

	<div class="amo-template-library-footer">
		<div class="amo-template-library-template-info">
			<h5 class="amo-template-library-template-title">{{{ title }}}</h5>
			<h6 class="amo-template-library-template-type">{{{ type }}}</h6>
		</div>

		<div class="amo-template-library-template-action-btn">
			{{{ amokit.library.getModal().getTemplateActionButton( obj ) }}}
			<a href="#" class="elementor-button amokit-template-library-preview-button">
				<i class="eicon-device-desktop" aria-hidden="true"></i>
				<?php esc_html_e( 'Preview', 'amokit-addons' ); ?>
			</a>
		</div>

	</div>

</script>

<script type="text/template" id="tmpl-elementor-amokit-library-templates-empty">
	<div class="elementor-template-library-blank-icon">
		<img src="<?php echo esc_url(ELEMENTOR_ASSETS_URL . 'images/no-search-results.svg'); ?>" class="elementor-template-library-no-results" />
	</div>
	<div class="elementor-template-library-blank-title"></div>
	<div class="elementor-template-library-blank-message"></div>
	<div class="elementor-template-library-blank-footer">
		<?php echo esc_html__( 'Want to learn more about the Amona Kit library?', 'amokit-addons' ); ?>
		<a class="elementor-template-library-blank-footer-link" href=<?php echo esc_url("https://nasdesigns.rf.gd"); ?> target="_blank"><?php echo esc_html__( 'Click here', 'amokit-addons' ); ?></a>
	</div>
</script>